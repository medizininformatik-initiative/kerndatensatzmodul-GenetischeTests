# mii-exa-befund-bundle-befund-fgfr2-fusion - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2027.0.0-ballot.rc2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-befund-bundle-befund-fgfr2-fusion**

## Example Bundle: mii-exa-befund-bundle-befund-fgfr2-fusion



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-befund-bundle-befund-fgfr2-fusion",
  "type" : "transaction",
  "timestamp" : "2022-12-16T13:47:00+01:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-patient-fgfr2-fusion",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-molgen-patient-fgfr2-fusion",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Patient_mii-exa-molgen-patient-fgfr2-fusion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-molgen-patient-fgfr2-fusion</b></p><a name=\"mii-exa-molgen-patient-fgfr2-fusion\"> </a><a name=\"hcmii-exa-molgen-patient-fgfr2-fusion\"> </a><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Anonymous Patient Female, DoB: 1964-05 ( pseudonymized (use: usual, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Known status of Patient\">Deceased:</td><td colspan=\"3\">false</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">10 DE </td></tr></table></div></div>"
      },
      "identifier" : [{
        "use" : "usual",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationValue",
            "code" : "PSEUDED"
          }]
        },
        "system" : "https://www.charite.de/fhir/sid/pseudonym",
        "value" : "3337167192"
      }],
      "gender" : "female",
      "birthDate" : "1964-05",
      "deceasedBoolean" : false,
      "address" : [{
        "type" : "both",
        "postalCode" : "10",
        "country" : "DE"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-molgen-patient-fgfr2-fusion"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-practitioner-lab",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-molgen-practitioner-lab",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Practitioner_mii-exa-molgen-practitioner-lab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-molgen-practitioner-lab</b></p><a name=\"mii-exa-molgen-practitioner-lab\"> </a><a name=\"hcmii-exa-molgen-practitioner-lab\"> </a><p><b>active</b>: true</p><p><b>name</b>: Dr. Daniel Schmidt(Official)</p></div></div>"
      },
      "active" : true,
      "name" : [{
        "use" : "official",
        "text" : "Dr. Daniel Schmidt",
        "family" : "Schmidt",
        "given" : ["Daniel"],
        "prefix" : ["Dr."]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Practitioner/mii-exa-molgen-practitioner-lab"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-practitioner-physician",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-molgen-practitioner-physician",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Practitioner_mii-exa-molgen-practitioner-physician\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-molgen-practitioner-physician</b></p><a name=\"mii-exa-molgen-practitioner-physician\"> </a><a name=\"hcmii-exa-molgen-practitioner-physician\"> </a><p><b>active</b>: true</p><p><b>name</b>: Dr. Linda Rubens(Official)</p></div></div>"
      },
      "active" : true,
      "name" : [{
        "use" : "official",
        "text" : "Dr. Linda Rubens",
        "family" : "Rubens",
        "given" : ["Linda"],
        "prefix" : ["Dr."]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Practitioner/mii-exa-molgen-practitioner-physician"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-befundbericht-fgfr2-fusion",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "mii-exa-molgen-befundbericht-fgfr2-fusion",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/molekulargenetischer-befundbericht|2027.0.0-ballot.rc2",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-report|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"DiagnosticReport_mii-exa-molgen-befundbericht-fgfr2-fusion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport mii-exa-molgen-befundbericht-fgfr2-fusion</b></p><a name=\"mii-exa-molgen-befundbericht-fgfr2-fusion\"> </a><a name=\"hcmii-exa-molgen-befundbericht-fgfr2-fusion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-molekulargenetischer-befundbericht.html\">MII PR MolGen Molekulargenetischer Befundbericht</a> version: 2027.0.0-ballot.rc2, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-genomic-report.html\">Genomic Report</a> version: 3.0.0</p></div><h2><span title=\"Codes:{http://loinc.org 51969-4}\">Genetic analysis report</span> (<span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span>) </h2><table class=\"grid\"><tr><td>Subject</td><td>Anonymous Patient Female, DoB: 1964-05 ( pseudonymized (use: usual, ))</td></tr><tr><td>Performer</td><td> <a href=\"Practitioner-mii-exa-molgen-practitioner-lab.html\">Practitioner Dr. Daniel Schmidt(official)</a></td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>Relevant Time</b></td></tr><tr><td><a href=\"Observation-mii-exa-molgen-diagnostische-implikation-fgfr2-fusion.html\"><span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs diagnostic-implication}\">Diagnostic Implication</span></a></td><td/><td>Final</td><td>2022-11-30</td></tr><tr><td><a href=\"Observation-mii-exa-molgen-variante-fgfr2-fusion.html\"><span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></a></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td><td>Final</td><td>2022-11-30</td></tr><tr><td><a href=\"Observation-mii-exa-molgen-therapeutische-implikation-fgfr2-fusion.html\"><span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs therapeutic-implication}\">Therapeutic Implication</span></a></td><td/><td>Final</td><td>2022-11-30</td></tr></table><p>Nachweis FGFR2-Fusion. Empfehlung: Hochselektive FGFR-Inhibitor-Therapie.</p></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/recommended-action",
        "valueReference" : {
          "reference" : "Task/mii-exa-molgen-medikationsempfehlung-fgfr2-fusion"
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-molgen-anforderung-fgfr2-fusion"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE",
          "display" : "Genetics"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "51969-4",
          "display" : "Genetic analysis report"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-fgfr2-fusion"
      },
      "performer" : [{
        "reference" : "Practitioner/mii-exa-molgen-practitioner-lab"
      }],
      "result" : [{
        "reference" : "Observation/mii-exa-molgen-diagnostische-implikation-fgfr2-fusion"
      },
      {
        "reference" : "Observation/mii-exa-molgen-variante-fgfr2-fusion"
      },
      {
        "reference" : "Observation/mii-exa-molgen-therapeutische-implikation-fgfr2-fusion"
      }],
      "conclusion" : "Nachweis FGFR2-Fusion. Empfehlung: Hochselektive FGFR-Inhibitor-Therapie."
    },
    "request" : {
      "method" : "PUT",
      "url" : "DiagnosticReport/mii-exa-molgen-befundbericht-fgfr2-fusion"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-anforderung-fgfr2-fusion",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-molgen-anforderung-fgfr2-fusion",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/anforderung-genetischer-test|2027.0.0-ballot.rc2"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"ServiceRequest_mii-exa-molgen-anforderung-fgfr2-fusion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-molgen-anforderung-fgfr2-fusion</b></p><a name=\"mii-exa-molgen-anforderung-fgfr2-fusion\"> </a><a name=\"hcmii-exa-molgen-anforderung-fgfr2-fusion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-molgen-anforderung-genetischer-test.html\">MII PR MolGen Anforderung genetischer Test</a> version: 2027.0.0-ballot.rc2</p></div><p><b>identifier</b>: <code>https://www.charite.de/fhir/auftragsnummern</code>/PRK4QE59A</p><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 108252007}\">Laboratory procedure (procedure)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 405825005}\">Therapierelevante genetische Veränderungen bei Intrahepatischem Gallengangskarzinom</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient-fgfr2-fusion.html\">Anonymous Patient Female, DoB: 1964-05 ( pseudonymized (use: usual, ))</a></p><p><b>authoredOn</b>: 2022-11-30</p><p><b>requester</b>: <a href=\"Practitioner-mii-exa-molgen-practitioner-physician.html\">Practitioner Dr. Linda Rubens(official)</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 109842005}, {http://fhir.de/CodeSystem/bfarm/icd-10-gm C22.1}\">Intrahepatic bile duct carcinoma (disorder)</span></p></div></div>"
      },
      "identifier" : [{
        "system" : "https://www.charite.de/fhir/auftragsnummern",
        "value" : "PRK4QE59A"
      }],
      "status" : "active",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "108252007",
          "display" : "Laboratory procedure (procedure)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "405825005",
          "display" : "Molecular genetic test (procedure)"
        }],
        "text" : "Therapierelevante genetische Veränderungen bei Intrahepatischem Gallengangskarzinom"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-fgfr2-fusion"
      },
      "authoredOn" : "2022-11-30",
      "requester" : {
        "reference" : "Practitioner/mii-exa-molgen-practitioner-physician"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "109842005",
          "display" : "Intrahepatic bile duct carcinoma (disorder)"
        },
        {
          "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
          "version" : "2024",
          "code" : "C22.1",
          "display" : "Intrahepatisches Gallengangskarzinom"
        }]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-molgen-anforderung-fgfr2-fusion"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-variante-fgfr2-fusion",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-variante-fgfr2-fusion",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/variante|2027.0.0-ballot.rc2",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/variant|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-variante-fgfr2-fusion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-variante-fgfr2-fusion</b></p><a name=\"mii-exa-molgen-variante-fgfr2-fusion\"> </a><a name=\"hcmii-exa-molgen-variante-fgfr2-fusion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-variante.html\">MII PR MolGen Variante</a> version: 2027.0.0-ballot.rc2, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-variant.html\">Variant</a> version: 3.0.0</p></div><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-molgen-anforderung-fgfr2-fusion.html\">ServiceRequest Molecular genetic test (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient-fgfr2-fusion.html\">Anonymous Patient Female, DoB: 1964-05 ( pseudonymized (use: usual, ))</a></p><p><b>effective</b>: 2022-11-30</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}, {http://loinc.org 86206-0}\">Sequencing</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3689}\">FGFR2</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48019-4}\">DNA change type</span></p><p><b>value</b>: <span title=\"Codes:{http://sequenceontology.org SO:0001565}\">gene_fusion</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 95123-6}\">Gene fusion transcript details in Blood or Tissue by Molecular genetics method Narrative</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:3689::HGNC:2697}\">FGFR2::DBP</span></p></blockquote></div></div>"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-molgen-anforderung-fgfr2-fusion"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-fgfr2-fusion"
      },
      "effectiveDateTime" : "2022-11-30",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        },
        {
          "system" : "http://loinc.org",
          "code" : "86206-0",
          "display" : "Whole genome sequence analysis in Blood or Tissue by Molecular genetics method"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3689",
            "display" : "FGFR2"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48019-4"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://sequenceontology.org",
            "code" : "SO:0001565",
            "display" : "gene_fusion"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "95123-6"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:3689::HGNC:2697",
            "display" : "FGFR2::DBP"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-molgen-variante-fgfr2-fusion"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-diagnostische-implikation-fgfr2-fusion",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-diagnostische-implikation-fgfr2-fusion",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/diagnostische-implikation|2027.0.0-ballot.rc2",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/diagnostic-implication|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-diagnostische-implikation-fgfr2-fusion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-diagnostische-implikation-fgfr2-fusion</b></p><a name=\"mii-exa-molgen-diagnostische-implikation-fgfr2-fusion\"> </a><a name=\"hcmii-exa-molgen-diagnostische-implikation-fgfr2-fusion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-diagnostische-implikation.html\">MII PR MolGen Diagnostische Implikation</a> version: 2027.0.0-ballot.rc2, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-diagnostic-implication.html\">Diagnostic Implication</a> version: 3.0.0</p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs diagnostic-implication}\">Diagnostic Implication</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient-fgfr2-fusion.html\">Anonymous Patient Female, DoB: 1964-05 ( pseudonymized (use: usual, ))</a></p><p><b>effective</b>: 2022-11-30</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-molgen-practitioner-lab.html\">Practitioner Dr. Daniel Schmidt(official)</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-molgen-variante-fgfr2-fusion.html\">Observation Genetic variant assessment</a></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs conclusion-string}\">Conclusion Text</span></td><td>starke Überexpression (25-fach)</td></tr></table></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "diagnostic-implication",
          "display" : "Diagnostic Implication"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-fgfr2-fusion"
      },
      "effectiveDateTime" : "2022-11-30",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-molgen-practitioner-lab"
      }],
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-molgen-variante-fgfr2-fusion"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "conclusion-string"
          }]
        },
        "valueString" : "starke Überexpression (25-fach)"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-molgen-diagnostische-implikation-fgfr2-fusion"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-therapeutische-implikation-fgfr2-fusion",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-therapeutische-implikation-fgfr2-fusion",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/therapeutische-implikation|2027.0.0-ballot.rc2",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/therapeutic-implication|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-therapeutische-implikation-fgfr2-fusion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-therapeutische-implikation-fgfr2-fusion</b></p><a name=\"mii-exa-molgen-therapeutische-implikation-fgfr2-fusion\"> </a><a name=\"hcmii-exa-molgen-therapeutische-implikation-fgfr2-fusion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-therapeutische-implikation.html\">MII PR MolGen Therapeutische Implikation</a> version: 2027.0.0-ballot.rc2, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-therapeutic-implication.html\">Therapeutic Implication</a> version: 3.0.0</p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs therapeutic-implication}\">Therapeutic Implication</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient-fgfr2-fusion.html\">Anonymous Patient Female, DoB: 1964-05 ( pseudonymized (use: usual, ))</a></p><p><b>effective</b>: 2022-11-30</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-molgen-practitioner-lab.html\">Practitioner Dr. Daniel Schmidt(official)</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-molgen-variante-fgfr2-fusion.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs conclusion-string}\">Conclusion Text</span></p><p><b>value</b>: Hochselektiver FGFR2-Inhibitor RLY-4008 bei Patienten mit Cholangiokarzinomen und anderen soliden Tumoren, mit oder ohne FGFR- gerichtete Vortherapie.</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 51963-7}\">Medication assessed [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.whocc.no/atc L01EN}, {http://snomed.info/sct 1162485005}\">Fibroblasten-Wachstumsfaktor-Rezeptor (FGFR)-Tyrosinkinase-Inhibitoren</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 93044-6}\">Level of evidence</span></p><p><b>value</b>: <span title=\"Codes:\">m1c</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81259-4}\">Associated phenotype</span></p><p><b>value</b>: <span title=\"Codes:{http://snomed.info/sct 109842005}, {http://fhir.de/CodeSystem/bfarm/icd-10-gm C22.1}\">Intrahepatic bile duct carcinoma (disorder)</span></p></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "therapeutic-implication",
          "display" : "Therapeutic Implication"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-fgfr2-fusion"
      },
      "effectiveDateTime" : "2022-11-30",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-molgen-practitioner-lab"
      }],
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-molgen-variante-fgfr2-fusion"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "conclusion-string"
          }]
        },
        "valueString" : "Hochselektiver FGFR2-Inhibitor RLY-4008 bei Patienten mit Cholangiokarzinomen und anderen soliden Tumoren, mit oder ohne FGFR- gerichtete Vortherapie."
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "51963-7",
            "display" : "Medication assessed [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.whocc.no/atc",
            "code" : "L01EN",
            "display" : "Fibroblasten-Wachstumsfaktor-Rezeptor (FGFR)-Tyrosinkinase-Inhibitoren"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "1162485005",
            "display" : "Substance with fibroblast growth factor receptor inhibitor mechanism of action (substance)"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "93044-6"
          }]
        },
        "valueCodeableConcept" : {
          "text" : "m1c"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81259-4"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "109842005",
            "display" : "Intrahepatic bile duct carcinoma (disorder)"
          },
          {
            "system" : "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
            "version" : "2024",
            "code" : "C22.1",
            "display" : "Intrahepatisches Gallengangskarzinom"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-molgen-therapeutische-implikation-fgfr2-fusion"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-medikationsempfehlung-fgfr2-fusion",
    "resource" : {
      "resourceType" : "Task",
      "id" : "mii-exa-molgen-medikationsempfehlung-fgfr2-fusion",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/medikationsempfehlung|2027.0.0-ballot.rc2",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/medication-recommendation|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Task_mii-exa-molgen-medikationsempfehlung-fgfr2-fusion\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Task mii-exa-molgen-medikationsempfehlung-fgfr2-fusion</b></p><a name=\"mii-exa-molgen-medikationsempfehlung-fgfr2-fusion\"> </a><a name=\"hcmii-exa-molgen-medikationsempfehlung-fgfr2-fusion\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-medikationsempfehlung.html\">MII PR MolGen Medikationsempfehlung</a> version: 2027.0.0-ballot.rc2, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-medication-recommendation.html\">Medication Recommendation</a> version: 3.0.0</p></div><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-molgen-anforderung-fgfr2-fusion.html\">ServiceRequest Molecular genetic test (procedure)</a></p><p><b>status</b>: Requested</p><p><b>intent</b>: proposal</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org LA26421-0}\">Hochselektive FGFR-Inhibitor-Therapie</span></p><p><b>for</b>: <a href=\"Patient-mii-exa-molgen-patient-fgfr2-fusion.html\">Anonymous Patient Female, DoB: 1964-05 ( pseudonymized (use: usual, ))</a></p><p><b>reasonReference</b>: <a href=\"Observation-mii-exa-molgen-therapeutische-implikation-fgfr2-fusion.html\">Observation Therapeutic Implication</a></p></div></div>"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-molgen-anforderung-fgfr2-fusion"
      }],
      "status" : "requested",
      "intent" : "proposal",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26421-0",
          "display" : "Consider alternative medication"
        }],
        "text" : "Hochselektive FGFR-Inhibitor-Therapie"
      },
      "for" : {
        "reference" : "Patient/mii-exa-molgen-patient-fgfr2-fusion"
      },
      "reasonReference" : {
        "reference" : "Observation/mii-exa-molgen-therapeutische-implikation-fgfr2-fusion"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Task/mii-exa-molgen-medikationsempfehlung-fgfr2-fusion"
    }
  }]
}

```
