# Examples - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2027.0.0-ballot.rc3

* [**Table of Contents**](toc.md)
* **Examples**

## Examples

This page lists the example instances of the **Molekulargenetischer Befundbericht** module. The template ships the synthetic example the [Artifacts Summary](artifacts.md).

**Synthetic data only** — never use real or realistic-looking patient data in examples.

