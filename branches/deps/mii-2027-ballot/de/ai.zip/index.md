# Startseite - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* **Startseite**

## Startseite

| | |
| :--- | :--- |
| *Offizielle URL*:https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/ImplementationGuide/mii-ig-molgen | *Version*:2027.0.0-ballot.1 |
| Active Stand: 2026-09-16 | *Maschinenlesbarer Name*:MII_IG_MolGen |

### Einleitung

Die vorliegende Spezifikation beschreibt die FHIR-Repräsentation des KDS-Moduls **Molekulargenetischer Befundbericht** der Medizininformatik-Initiative (MII). Sie umfasst die Anwendungsfälle des Moduls sowie die dazugehörigen FHIR-Profile, Extensions und Terminologie-Ressourcen in ihrer verbindlichen Form. Der MII-Kerndatensatz ermöglicht die standardisierte Sekundärnutzung klinischer Routinedaten für die medizinische Forschung.

| | |
| :--- | :--- |
| Datum | 2026-09-16 |
| Version | 2027.0.0-ballot.1 |
| Status | active |
| Realm | DE |

### Zielgruppen

##### Implementierende

Datenintegrationszentren (DIZ), Softwareentwickelnde und Systemarchitektinnen und -architekten, die FHIR-basierte Lösungen umsetzen.
 → siehe [Profile](profiles.md) und [Logische Modelle](logical-models.md).

##### Forschende

Wissenschaftlerinnen und Wissenschaftler, die KDS-Daten für die medizinische Forschung nutzen.
 → siehe [Anleitung](guidance.md).

### Inhalt

* **[Anleitung](guidance.md)** — Einstieg und fachliche Hinweise.
* **Konformität** — die KDS-weiten Konformitätsregeln (Anforderungssprache, Must Support, Umgang mit fehlenden Daten) werden zentral vom [Meta-Modul](https://github.com/medizininformatik-initiative/kerndatensatz-meta/wiki/Conformance) gepflegt; die modul-spezifischen Aspekte zu [Sicherheit und Datenschutz](security-and-privacy.md) sind Teil dieses Leitfadens.
* **[Profile](profiles.md)** und die weiteren **[Artefaktseiten](artifacts.md)** — die technischen Artefakte.
* **[Beispiele](examples.md)** — Beispielinstanzen.
* **[Abhängigkeiten](ImplementationGuide-mii-ig-molgen.md)** — die ImplementationGuide-Ressource mit der Abhängigkeitstabelle, der Cross-Version-Analyse und den Copyright-Angaben.

### Verwandte Leitfäden

Dieses Modul ist Teil des MII-Kerndatensatzes; die übrigen KDS-Module und ihre Abhängigkeiten sind unter [medizininformatik-initiative.de](https://www.medizininformatik-initiative.de/) beschrieben. Wie sich dieses Modul zu den anderen MII-Modulen verhält, beschreibt die [Anleitung für Implementierende](implementer-guidance.md).

Dieser Leitfaden baut auf den folgenden Paketen auf. Die Tabelle stammt aus `dependencies:` in `sushi-config.yaml` und kann deshalb nicht von dem abweichen, was der Build tatsächlich auflöst:

| | | |
| :--- | :--- | :--- |
| `hl7.fhir.uv.genomics-reporting` | `3.0.0` | HL7 Clinical Genomics Reporting STU3 — die internationale Basis, von der jedes genetische Profil hier abstammt |
| `de.medizininformatikinitiative.kerndatensatz.meta` | `2027.0.0-ballot.rc3` | MII-Kerndatensatz-Modul Meta — Provenienz und die gemeinsamen Suchparameter |
| `de.basisprofil.r4` | `1.6.0` | Deutsche Basisprofile — Identifikatoren, Adressen, Versicherung |
| `de.medizininformatikinitiative.kerndatensatz.base` | `2027.0.0-ballot.rc1` | MII-Kerndatensatz-Modul Basis — Patient, Encounter und die modulübergreifenden Grundlagen |
| `de.medizininformatikinitiative.kerndatensatz.biobank` | `2027.0.0-ballot.rc2` | MII-Kerndatensatz-Modul Biobank — die Specimen-Profile, auf die die genomischen Studien verweisen |
| `hl7.terminology.r4` | `7.3.0` | HL7 Terminology — die Codesysteme, auf die sich die FHIR-Kernspezifikation stützt |
| `hl7.fhir.uv.crmi` | `2.0.0` | Canonical Resource Management Infrastructure — erklärt, wie dieser Leitfaden seine Artefakte versioniert |
| `hl7.fhir.uv.extensions.r4` | `5.3.0` | HL7-Extension-Paket |

Weitere FHIR-Implementierungsleitfäden finden sich in der offiziellen **[FHIR IG Registry](https://fhir.org/guides/registry/)** (Quelle: [`FHIR/ig-registry`](https://github.com/FHIR/ig-registry)).

### Danksagung

Zwölf der einundzwanzig Profile dieses Moduls leiten sich unmittelbar von [HL7 Clinical Genomics Reporting STU3](http://hl7.org/fhir/uv/genomics-reporting/STU3/) ab — Variante, Genotyp, Molekulare Konsequenz, Molekularer Biomarker, die beiden Implikationsprofile, GenomicStudy und GenomicStudyAnalysis und der Befundbericht selbst. Das fachliche Modell dahinter, die Komponentenstruktur, die Terminologiebindungen und die Benennung stammen von der **HL7 Clinical Genomics Working Group**. Dieses Modul schränkt ein, benennt auf Deutsch und ergänzt den MII-Kontext; es erfindet die Modellierung nicht neu.

Das betrifft auch die Autorenangabe in den Artefakt-Metadaten. Die Artefakte dieses Moduls tragen eine [CRMI](https://hl7.org/fhir/uv/crmi/)-Auszeichnung, darunter `artifact-author`. Diese Angabe bezieht sich auf die **MII-spezifische Einschränkung**, nicht auf das zugrunde liegende Modell. Clinical Genomics Reporting führt selbst keine CRMI-Metadaten; die Auszeichnung hier ersetzt keine Urheberschaft und beansprucht keine.

### Impressum

Dieser Leitfaden ist im Rahmen der Medizininformatik-Initiative erstellt worden und unterliegt per Governance-Prozess dem Abstimmungsverfahren des Interoperabilitätsforums und der Technischen Komitees (TCs) von HL7 Deutschland e. V.

### Kontakt

Fragen zu der vorliegenden Publikation können im HL7-FHIR-Zulip [chat.fhir.org](https://chat.fhir.org) im Stream `german/mi-initiative` gestellt werden oder im MII-Zulip [mii.zulipchat.com](https://mii.zulipchat.com/) im Stream `MII-Kerndatensatz`. Anmerkungen und Kritik werden als **Issues** auf [GitHub](https://github.com/medizininformatik-initiative/kerndatensatzmodul-GenetischeTests/issues) stets gern entgegengenommen.

Ansprechpersonen für die fachlichen Inhalte des Moduls:

* Sylvia Thun, Berlin Institute of Health at Charité (BIH)
* Thomas Debertshäuser, Berlin Institute of Health at Charité (BIH)
* Julian Saß, Berlin Institute of Health at Charité (BIH)
* Karoline Buckow, TMF – Technologie- und Methodenplattform für die vernetzte medizinische Forschung e.V.
* Franziska Klepka, TMF – Technologie- und Methodenplattform für die vernetzte medizinische Forschung e.V.

### Autoren (in alphabetischer Reihenfolge)

* Alexander Zautke (HL7 Deutschland)
* Andrew Heidel (SMITH)
* Anna Trelinska-Finger (HiGHmed)
* Arsenij Ustjanzew (MIRACUM)
* Bernd Auber (HiGHmed)
* Brigitte Schlegelberger (HiGHmed)
* Caroline Stellmach (BIH at Charité)
* Franziska Klepka (MII-Koordinationsstelle)
* Frederick Klauschen (Charité)
* Julian Saß (BIH at Charité)
* Karoline Buckow (MII-Koordinationsstelle)
* Kirsten Toralf (SMITH)
* Manuela Benary (Charité)
* Martin Boeker (DIFUTURE)
* Michael Krawczak (HiGHmed)
* Oliver Kohlbacher (DIFUTURE)
* Patrick Werner (MOLIT Institut gGmbH)
* Simon Schumacher (HiGHmed)
* Sylvia Thun (Charité)
* Stefan Fröhling (GenomDE)
* Stephan Ossowski (DIFUTURE)
* Thomas Debertshäuser (BIH at Charité)
* Thomas Wienker (GenomDE)
* Yvonne Möller (GenomDE)

### Copyright und Lizenz

Copyright © 2022+: TMF e. V., Charlottenstraße 42, 10117 Berlin

Dieses Werk ist lizenziert unter der [Creative-Commons-Namensnennung-4.0-International-Lizenz (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/deed.de).

Zu den Nutzungsrechten der zugrunde liegenden FHIR-Technologie siehe die FHIR-Basisspezifikation.

Einige der verwendeten Codesysteme werden von anderen Organisationen herausgegeben und gepflegt; es gilt das Copyright der jeweiligen Herausgeber.

### Disclaimer

Der Inhalt dieses Dokuments ist öffentlich. Zu beachten ist, dass Teile dieses Dokuments auf FHIR Version R4 beruhen, für die das Copyright von HL7 International gilt.

Obwohl diese Publikation mit größter Sorgfalt erstellt wurde, können die Autoren keinerlei Haftung für direkten oder indirekten Schaden übernehmen, der durch den Inhalt dieser Spezifikation entstehen könnte.

