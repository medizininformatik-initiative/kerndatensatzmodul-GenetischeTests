# Änderungshistorie - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* **Änderungshistorie**

## Änderungshistorie

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

### Änderungshistorie

Diese Seite hält die Änderungen zwischen den veröffentlichten Versionen des Moduls **Molekulargenetischer Befundbericht** fest, die neueste Version zuerst. Sie folgt [Keep a Changelog](https://keepachangelog.com/de/1.1.0/) und dem KDS-CalVer-Schema, das die Seite [Versionierung](version-history.md) beschreibt.

Jede Version erhält einen eigenen Abschnitt mit dem Release-Datum und ihren Änderungen. Dafür stehen diese Kategorien zur Verfügung:

* **Hinzugefügt** — neue Profile, Extensions, ValueSets, Suchparameter, Seiten.
* **Geändert** — geänderte Einschränkungen, Bindings, Hinweise oder Dokumentation.
* **Abgekündigt** — Artefakte, die noch existieren, aber nicht mehr genutzt werden sollen.
* **Entfernt** — zurückgezogene Artefakte.
* **Behoben** — Korrekturen von Fehlern.
* **Sicherheit** — Änderungen mit Auswirkung auf Sicherheit oder Datenschutz.

Kategorien ohne Inhalt werden weggelassen. Geht eine Änderung auf ein Issue oder einen Pull-Request zurück, wird darauf verlinkt.

Die Versionsabschnitte gruppieren ihre Einträge **thematisch** — nach betroffenem Profil oder Bereich — statt nach diesen Kategorien. Beides lässt die Vorlage zu, und für ein FHIR-Modul trägt die thematische Achse weiter: Eine umbenannte Komponente ist **Hinzugefügt** und **Entfernt** zugleich, und wer wissen will, was sich an Variante geändert hat, findet es so an einer Stelle.

**Sicherheit ist davon ausgenommen.** Änderungen mit Auswirkung auf Sicherheit oder Datenschutz bekommen immer einen eigenen, so benannten Block — sie müssen auffindbar sein, ohne dass man thematische Abschnitte danach durchsucht. Bisher gab es keine.

##### Breaking Changes MÜSSEN berichtet und erläutert werden

Ein Versionsabschnitt mit einer Breaking Change ist erst vollständig, wenn er ausdrücklich und in diesem Changelog beantwortet:

* **Was genau sich geändert hat** zwischen den beiden Versionen — das Artefakt, das Element, die alte und die neue Einschränkung (nicht nur „Profil X wurde überarbeitet“).
* **Was das für bestehende Daten bedeutet:** Validieren Daten, die der Vorversion entsprachen, weiterhin gegen die neue Version? Falls nein: welche Ressourcen und Elemente sind betroffen, und wie zeigt sich der Fehler?
* **Was Implementierende tun sollten:** die Empfehlung der Autorinnen und Autoren zur Migration bestehender Daten auf die neue Version — Transformationsschritte, Standardwerte, Umkodierungs-Hinweise — oder die ausdrückliche Aussage, dass kein Migrationspfad bereitgestellt wird, und warum.

**Was als Breaking Change zählt** — behandeln Sie eine Änderung als Breaking Change, wenn sie eines der Folgenden tut, auch wenn sie klein wirkt: eine Kardinalität verschärft (`0..*` → `1..1`), eine Binding-Stärke erhöht (example → required), Codes aus einem required-ValueSet entfernt, ein Element oder einen Slice entfernt oder umbenennt, einen Typ einengt, eine Invariante oder eine Must-Support-Pflicht hinzufügt oder eine kanonische URL ändert. Im Zweifel: als Breaking Change berichten.

**Breaking für wen:** benennen Sie beide Perspektiven — *gespeicherte Daten* (Instanzen, die gegen die alte Version valide sind) und *Implementierungen* (Clients und Server, die dagegen gebaut wurden; ein entfernter Suchparameter bricht Implementierungen, während jede gespeicherte Instanz valide bleibt).

**Die Versionsnummer warnt niemanden.** Das KDS-Kalender-Versionsschema (`JJJJ.n.n`) trägt kein Major-Signal wie SemVer — dieser Changelog-Abschnitt ist die *einzige* Warnung, die Lesende bekommen.

**Verlinken Sie das technische Delta.** Ab der zweiten formalen Publikation aktivieren Sie den Versionsvergleich des IG Publishers (`version-comparison` in `sushi-config.yaml` — siehe die Seite [Versionierung](version-history.md) zur Einrichtung und ihren Voraussetzungen); er veröffentlicht einen maschinell erzeugten Vergleich unter `comparison-v<Vorversion>/index.html`. Verlinken Sie ihn aus dem Versionsabschnitt, damit die Erläuterung und der technische Diff nebeneinanderstehen.

Kennzeichnen Sie solche Einträge deutlich (zum Beispiel mit dem Präfix **BREAKING:**), damit sie beim Überfliegen des Abschnitts nicht übersehen werden können.

-------

#### Version 2027.0.0-ballot.1

**Datum:** 2026-09-16 · **Ballot**

Korrektur an den Abhängigkeitsangaben. **Kein Profil, keine Extension, kein ValueSet und kein Beispiel ändert sich.**

##### Keine Breaking Changes

##### Abhängigkeiten auf die Ballot-Versionen der MII-Module

`2027.0.0-ballot` verwies auf Release-Kandidaten der drei MII-Module, obwohl von allen dreien die Ballot-Version vorlag:

| | | |
| :--- | :--- | :--- |
| `kerndatensatz.meta` | `2027.0.0-ballot.rc3` | `2027.0.0-ballot` |
| `kerndatensatz.base` | `2027.0.0-ballot.rc1` | `2027.0.0-ballot` |
| `kerndatensatz.biobank` | `2027.0.0-ballot.rc2` | `2027.0.0-ballot` |

Ein Ballot, der gegen Kandidaten anderer Module validiert, ist inkonsistent — Prüfende hätten gegen Stände geprüft, die selbst als vorläufig gekennzeichnet sind.

**Inhaltlich folgenlos, und das ist nachgemessen.** Ein Build gegen die alten und ein Build gegen die neuen Abhängigkeiten unterscheiden sich in **139 von 140 Ressourcen überhaupt nicht**; die einzige Abweichung ist die ImplementationGuide-Ressource mit den drei geänderten Versionsangaben. Die Upstream-Pakete sind zwar gewachsen — meta von 173 auf 177, base von 36 auf 38, biobank von 44 auf 49 Ressourcen —, aber nichts davon berührt, was dieses Modul verwendet: acht SearchParameter aus meta, einen IG-Verweis aus base und `SpecimenCore` aus biobank.

#### Version 2027.0.0-ballot

**Datum:** 2026-09-15 · **Ballot**

Die Ballot-Version der 2027er-Linie. **Inhaltlich identisch mit 2027.0.0-ballot.rc3** — diese Publikation trägt die Ballot-Kennzeichnung, sie ändert nichts an Profilen, Extensions, ValueSets oder Beispielen.

##### Keine Breaking Changes

Gegenüber rc3 hat sich kein Artefakt geändert. Wer gegen rc3 implementiert hat, implementiert gegen diese Version.

##### Was die drei Kandidaten hierher gebracht haben

* **rc1** brachte das Modul auf das MII-KDS-Modul-Template: der Leitfaden wird vom HL7 IG Publisher gebaut statt von Simplifier, englisch mit deutscher Übersetzung.
* **rc2** pinnte alle extern versionierten Codesysteme — SNOMED CT, LOINC, HGNC, HPO, Sequence Ontology und ICD-10-GM — und brachte die Migration von Clinical Genomics STU2 auf STU3 als Seite in den Leitfaden.
* **rc3** schloss die Metadaten und die Redaktion ab: CRMI an allen 33 Artefakten, der modulspezifische Sicherheits- und Datenschutzabschnitt, die Danksagung an die HL7 Clinical Genomics Working Group und die Dokumentation der bekannten Probleme.

##### Publikationsstatus

Der Eintrag im FHIR-IG-Registry trägt diese Version als Edition **2027**. Die `publication-request.json` führt `status: release`, wie es die MII-Referenzmodule handhaben.

#### Version 2027.0.0-ballot.rc3

**Datum:** 2026-09-14 · **Release-Kandidat**

Der dritte Kandidat schließt, was rc2 offengelassen hat: die Artefakt-Metadaten, die Sicherheitsanalyse und die offenen Redaktionsvermerke.

##### Keine Breaking Changes

Geprüft: keine kanonische URL, kein Profilname, kein Slice und keine Kardinalität hat sich geändert. Was hinzukommt, sind Metadaten an den Artefakten und Text im Leitfaden. Instanzen, die gegen rc2 valide waren, bleiben es.

##### Metadaten

* **CRMI ist an allen 33 Artefakten angeschlossen** — 22 StructureDefinitions, 4 ValueSets, 6 SearchParameter und das CapabilityStatement. Bis rc2 beanspruchte nur der ImplementationGuide selbst CRMI, während 32 fertige RuleSets ungenutzt im Repository lagen; das publizierte rc2-Paket trägt 0 von 22 StructureDefinitions mit CRMI-Anspruch.


  Dazu gehören `artifact-author`, die MII-weiten Gremienangaben aus Editor, Reviewer und Endorser, `artifact-topic`, `resource-approvalDate`, `artifact-versionPolicy`, `cqf-knowledgeCapability` und die Paketherkunft. Die SearchParameter tragen zusätzlich `artifact-title`, weil `crmi-publishablesearchparameter` einen Titel verlangt und SearchParameter kein natives `title` kennt.

##### Sicherheit und Datenschutz

* **Der modulspezifische Abschnitt ist geschrieben.** Er stand seit der Migration als Platzhalter und hatte rc1 und rc2 überlebt, obwohl er selbst sagte, er müsse vor dem ersten Release erfolgen.


  Er ist an den tatsächlich geführten Elementen belegt: HGVS auf DNA- und Genomebene mit exakten Positionen, Referenz- und Alternativallel, die Unterscheidung Keimbahn gegen somatisch und die Angaben zu Verwandten in der Familienanamnese. Daraus folgt, was den Abschnitt trägt — **die Sequenzangaben sind selbst der Identifikator**, weshalb eine Pseudonymisierung auf Profilebene das Re-Identifikationsrisiko nicht beseitigt. Fünf Anforderungen als SHALL, SHOULD und MAY benennen jeweils das adressierte Risiko.

##### Dokumentation

* **Die Clinical Genomics Working Group wird auf der Startseite gewürdigt.** Zwölf der einundzwanzig Profile leiten sich unmittelbar von Clinical Genomics Reporting STU3 ab; das fachliche Modell, die Komponentenstruktur, die Terminologiebindungen und die Benennung stammen von dort. Die `artifact-author`-Angabe bezieht sich auf die MII-spezifische Einschränkung und beansprucht keine Urheberschaft am Modell.
* **Breaking Changes tragen jetzt das Präfix `BREAKING:`** in der Überschrift — die kanonische URL der Familienanamnese und die URL-Namensraum-Migration, beide aus der 2026er-Linie.
* Alle **redaktionellen Vermerke der Template-Migration sind aufgelöst**: sechs waren reine Protokolle, fünf brauchten eine Entscheidung und haben sie bekommen. Die Klammer „(CalVer `YYYY.n.n`)" hinter der Versionsangabe war ein Autorenhinweis der Vorlage und ist entfernt.

#### Version 2027.0.0-ballot.rc2

**Datum:** 2026-09-07 · **Release-Kandidat**

Der erste Kandidat wurde formal publiziert; dieser räumt auf, was dabei sichtbar wurde.

##### Keine Breaking Changes

Geprüft statt angenommen — die CalVer-Nummer warnt von sich aus nicht.

Der SNOMED-CT-Pin springt ein volles Jahr, von `20250701` auf `20260701`; das ist die einzige Änderung hier, die Codes hätte entfernen oder inaktivieren können. Alle **49** verschiedenen SNOMED-Codes dieses Moduls wurden gegen beide Versionen am MII-Terminologieserver abgefragt: **keiner unterscheidet sich** — gleiche Existenz, gleiches Display. Instanzen, die gegen rc1 valide waren, bleiben es gegen rc2.

Die fünf neu gepinnten Systeme schränken künftige Expansionen ein, ändern heute aber nichts: jedes wurde auf die Version gepinnt, die der Server ohnehin als Vorgabe lieferte. Die übrigen Änderungen betreffen Dokumentation und Release-Automatisierung.

##### Terminologie

* **Alle extern versionierten Codesysteme sind jetzt gepinnt**, nicht nur SNOMED CT. Das Expansions-Manifest band eines von sechzehn in Frage kommenden Systemen, während seine eigene Dokumentation zusagt, eine Expansion liefere „dieselben Codes heute, zum Release-Zeitpunkt und in drei Jahren". Allein LOINC trägt hier 286 Codings und war ungepinnt.


  Jede Version wurde am MII-Terminologieserver abgefragt, nicht geraten. HGVS, ATC und Orphanet sind nicht gepinnt, weil der Server für sie keine Version liefert; UCUM ist konstruktionsbedingt versionslos.

##### Dokumentation

* **Migration von STU2 auf STU3** ist jetzt eine Seite im Guide. Sie führt zwei Dokumente zusammen, die unveröffentlicht im Repository-Wurzelverzeichnis lagen, und korrigiert drei Fehler, die beim Abgleich gegen die gebauten Artefakte auffielen — vor allem die zweite `category`, die Mikrosatelliteninstabilität und Mutationslast brauchen: sie war mit falschem Code und falschem System angegeben und ist der häufigste Validierungsfehler beim Überführen von Daten der 2025er-Linie.
* Diese Anleitung enthält **bewusst keine StructureMaps**: Die Datenintegration eines Datenintegrationszentrums läuft über eigene ETL-Strecken und enthält selten eine FHIR-Mapping-Engine, deshalb stehen die Abbildungen deklarativ da.

##### Release-Automatisierung

* Fünf Fehler im gemeinsamen Modul-Template wurden hier behoben, von denen jeder nur Module trifft, die etwas zum ersten Mal tun: der Release-Guard hielt dokumentierte ``-Platzhalter in Kommentaren für eine uninstanziierte Vorlage und übersprang stillschweigend den gesamten Release-Pfad; die erste formale Publikation legte weder `package-registry.json` noch die beiden RSS-Feeds an, die ihre eigene `publish-setup.json` deklariert; der `-go-publish`-Aufruf bekam die Terminologie-Allowlist nicht, die der Build-Aufruf erhält; und der Registry-Prüfer wies den Editionsnamen „`<Sequence> <Status>`" zurück, den jede Nicht-Release-Publikation bekommt.

##### Bekannte Probleme

Der QA-Bericht dieser Version meldet **53 Fehler**. Sie sind einzeln geprüft; die Grundlast und ihre Einordnung stehen in `known_errors.txt` im Repository. Zwei Gruppen verdienen hier eine Erklärung, weil sie sonst wie Datenfehler aussehen.

**Neun SNOMED-CT-Codes im Verwandtschafts-ValueSet.** Der Bericht sagt, sie seien „not valid in the system". Sie sind es. Jeder der neun wurde am MII-Terminologieserver gegen die hier gepinnte Version `…/900000000000207008/version/20260701` einzeln nachgeschlagen — alle vorhanden, alle aktiv, alle mit dem erwarteten Display:

| | |
| :--- | :--- |
| `66839005` | Father |
| `699110007` | Second degree blood relative |
| `13646006` | Natural parent |
| `60614009` | Natural brother |
| `73678001` | Natural sister |
| `45929001` | Half-brother |
| `2272004` | Half-sister |
| `62296006` | Natural grandfather |
| `17945006` | Natural grandmother |

Was scheitert, ist die **Form der Anfrage**, nicht der Code. Die vollständige Meldung nennt den Grund: **„Type-level request to `$validate-code` must specify either valueSet or url parameter."** Der Validator fragt einen Code ohne den Kontext ab, in dem der Server ihn prüfen kann; der Server lehnt die Anfrage ab, und der Validator meldet das als ungültigen Code. Nichts an den Daten dieses Moduls ist davon betroffen.

**Ein Genfusions-Code, der keiner ist.** Das Beispiel `mii-exa-molgen-variante-fgfr` trägt in der Komponente `gene-fusion`:

```
http://www.genenames.org/geneId#HGNC:3689::HGNC:2697   "FGFR2::DBP"

```

Das ist die HGVS-Schreibweise einer Fusion — zwei HGNC-Identifikatoren, verkettet mit `::`. HGNC selbst kennt `HGNC:3689` und `HGNC:2697` einzeln, die Verkettung ist dort kein Code. Der Fehler bleibt in dieser Version **bewusst stehen**: eine tragfähige Modellierung von Genfusionen gehört nicht hierher, sondern ins [Erweiterungsmodul Molekulares Tumorboard](https://simplifier.net/mii-erweiterungsmodul-molekulares-tumorboard), das dafür eine detaillierte Abbildung auf Basis des **dnpm**-Datensatzes vorsieht. Bis dahin zeigt das Beispiel, was gemeint ist, ohne vorzugeben, dass die Kodierung terminologisch trägt.

##### Dokumentation (zweiter Durchgang)

* **Das Domänenmodell ist jetzt im Leitfaden zu sehen.** Es lag als Bild im Repository, ohne dass eine Seite es einband; es steht nun auf [Logische Modelle](logical-models.md), weil es genau das illustriert, was die Seite beschreibt. Die PlantUML-Quelle wurde dabei zweisprachig: eine sprachneutrale Struktur und je eine Beschriftungsdatei mit denselben 113 Variablen. Zwei vollständige Kopien hätten sich über die Jahre auseinanderentwickelt.
* **Vier offene Punkte beantwortet statt vertagt.** Die Komponente `prognosis` entfällt **ersatzlos** — geprüft gegen alle STU3-Profile (`implication`, `diagnostic-implication`, `therapeutic-implication`, `molecular-consequence`): keines trägt einen Prognose-Slice, ein Profil `genomic-implication` existiert nicht. Der ValueSet-Verweis auf TherapeutischeImplikation nannte den toten STU2-Namen `therapeutic-implication-vs` und heißt jetzt `genetic-therapeutic-implications-vs`, wie das Elternprofil bindet. Die acht Paketabhängigkeiten stehen als Tabelle auf der Startseite.
* **Die Gruppierung dieses Changelogs ist entschieden.** Die Versionsabschnitte bleiben thematisch statt nach Keep-a-Changelog-Kategorien, weil eine umbenannte Komponente **Hinzugefügt** und **Entfernt** zugleich ist. **Sicherheit** ist die Ausnahme und bekommt immer einen eigenen Block.

##### Release-Automatisierung (zweiter Durchgang)

* **Ein Release wird nicht mehr von Hand veröffentlicht.** Bisher legte der Workflow einen Draft an, dessen Text sagte „Add your own release notes here" — der Handgriff war also nicht die Prüfung, sondern das Abtippen von etwas, das auf dieser Seite längst steht. Der Workflow liest den Abschnitt der Version jetzt von hier und veröffentlicht damit direkt. Fehlt der Abschnitt, wird gedraftet statt veröffentlicht.
* `fhirpkg.lock.json` nannte für `kerndatensatz.biobank` noch `rc1`, während `sushi-config.yaml` auf `rc2` zeigt. Der Build war nie betroffen — SUSHI löst gegen `sushi-config.yaml` auf —, aber die Sperrdatei log.

#### Version 2027.0.0-ballot.rc1

**Datum:** 2026-09-02 · **Release Candidate**

Erster Release Candidate auf Basis des MII-KDS-Modul-Templates. Der Leitfaden wird jetzt vom HL7 IG Publisher gebaut und gerendert statt von Simplifier, englisch mit deutscher Übersetzung.

* **Migration auf das MII-KDS-Modul-Template** (v0.13.0), das das gemeinsame MII-IG-Template referenziert. Alle 41 Seiten des bisherigen Simplifier-Leitfadens wurden in den Template-Seitensatz überführt: 15 wurden zu Intro-Notes über den generierten Artefaktseiten, der Rest ging in die vereinbarten Seiten. Identität, kanonische URLs und Artefaktmenge sind unverändert.
* **Lizenz deklariert:** CC BY 4.0. Die bisherigen Releases nannten keine Lizenz.
* **Abhängigkeiten:** `kerndatensatz.meta` und `kerndatensatz.base` auf die 2027er-Ballot-Kandidaten, `de.basisprofil.r4` auf 1.6.0, `hl7.terminology.r4` von 6.1.0 auf 7.3.0 und `kerndatensatz.biobank` von 2026.0.1 auf `2027.0.0-ballot.rc2`. Das `2027.0.0-ballot.rc1` des Biobank-Moduls war nicht nutzbar: sein Profil `SpecimenCore` und das davon abgeleitete `Specimen` wurden ohne Snapshot ausgeliefert, was der Build dieses Moduls zurückweist. `rc2` bringt für alle 24 StructureDefinitions Snapshots mit, und die Canonicals sind unverändert — die sechs `SpecimenCore`-Beispiele hier mussten also nicht angepasst werden.
* **CapabilityStatement korrigiert:** Die sechs eigenen Suchparameter des Moduls sind jetzt deklariert (sie fehlten vollständig), und eine falsche Kanonische beim FamilyMemberHistory-Parameter `reason-code` wurde behoben.
* **Suchparameter** stehen auf einer eigenen Seite, aus den gebauten Artefakten abgeleitet statt von Hand gepflegt.
* **Neues Beispiel:** ein FFPE-Tumorgewebe-Specimen für die TSO500-Panel-Studie, auf das zwei GenomicStudyAnalysis-Beispiele verwiesen, das es aber nie gab.
* **Sechs DiagnosticReport-Beispiel-IDs gekürzt**, damit das Paket überhaupt baubar ist — die bisherigen IDs erzeugten einen Paketpfad über der 100-Byte-Grenze des tar-Formats. Alt → neu: `mii-exa-molgen-molekulargenetischer-befundbericht-*` → `mii-exa-molgen-befundbericht-*`.

##### Konformitätserwartungen

* **Drei Profile sind jetzt `MAY` statt `SHALL`:** `genotyp` sowie die beiden Clinical-Genomics-STU3-Profile `haplotype` und `sequence-phase-relationship`. Alle drei sagen etwas über Allele als Ganzes aus statt über einen Einzelbefund, und viele Labore leiten sie nie ab. `sequence-phase-relationship` war zuvor gar nicht deklariert, obwohl die Implementiererseite es als verwendet darstellte; `haplotype` stand auf `SHALL` und verpflichtete damit zu etwas, wozu der Guide kein Beispiel zeigt.
* **`MII_PR_MolGen_MolekularerBiomarker` ist jetzt deklariert** (`SHALL`). Es ist das Elternprofil von Mikrosatelliteninstabilität und Mutationslast, die beide gefordert waren, während ihr Basisprofil unerwähnt blieb.
* **`DiagnosticReport.result:biomarker` ist darauf verengt.** Zuvor erbte der Slice von STU3 und akzeptierte jedes `molecular-biomarker`.
* **Drei supportedProfile-Einträge zeigten auf Canonicals, die es nicht gibt** — `molekulare-konsequenz`, `genomic-study` und `genomic-study-analysis` waren ohne den Präfix `mii-pr-molgen-` geschrieben, den diese drei Profile tatsächlich tragen. Ein Server hätte sie nicht auflösen können. Die Canonicals selbst bleiben unverändert: sie stehen so im veröffentlichten Paket 2026.0.4.

##### Dokumentation

* **Die Abhängigkeit von Clinical Genomics STU3 ist jetzt korrekt beziffert.** Die Implementiererseite dokumentierte zwei Profile; tatsächlich erben zehn Profile direkt, zwei indirekt, eine Extension erbt, zwölf Extensions werden verwendet, dazu drei ValueSets und zwei Codesysteme.
* **Die CapabilityStatement-Seite trägt eine Tabelle Profil/Erwartung.** Der IG Publisher rendert die unterstützten Profile als reine Linkliste ohne die `SHALL`/`MAY`-Erwartung — ohne diese Tabelle wären die Erwartungen im gerenderten Guide unsichtbar.
* **Die Suchparameter stehen nur noch an einer Stelle.** Die nummerierten Listen auf allen 14 Profil-Intro-Seiten wurden entfernt (3373 Zeilen); sie doppelten das CapabilityStatement, wichen davon ab und nannten das falsche Modul.
* **Elementnamen korrigiert**, die es in STU3 nicht gibt: `CytogenicLocation` → `cytogenetic-location`, `RefSequenceAssembly` → `reference-sequence-assembly`, `associated-phenotype` → `predicted-phenotype`. Ein Mapping auf `amino-acid-change-type` entfiel: STU3 kennt diese Komponente auf `variant` nicht, und das Datensatzelement ist nach `molecular-consequence` gewandert.

##### Korrekturen an Beispielen

* `Task.basedOn` verwies in zwei Beispielen auf `servicerequest/example` — ein Platzhalter mit kleingeschriebenem Ressourcentyp, der ins Leere zeigte. Jetzt die BRAF-Anforderung.
* Zwei Beispiele beanspruchten die STU2-Profile `msi` und `tmb`, die STU3 in `molecular-biomarker` zusammengeführt hat.
* Zwei Gen-IDs im TSO500-Panel waren falsch: `HGNC:3942` (das ist MTOR) mit dem Label FGFR2 und `HGNC:3943` (existiert nicht) mit dem Label FGFR3. Richtig sind `HGNC:3689` und `HGNC:3690`.
* Eine Practitioner-Referenz im umfassenden WES-Bundle zeigte auf eine Ressource, die es nirgends gibt.
* **`known_errors.txt` wurde angelegt.** Von den Validierungsfehlern geht die große Mehrheit auf Grenzen des Terminologieservers zurück und nicht auf Defekte dieses Moduls; die Datei sagt, was was ist, und hält den einen bewusst hingenommenen Fehler fest (die FGFR2::DBP-Fusionscodierung, bei der LOINC 95123-6 narrativ skaliert ist, das Profil den Slice aber an CodeableConcept bindet).

#### Version 2026.0.4

**Datum:** 2026-01-02

##### Package Build & Versionskonsistenz

**Problem**: v2026.0.3 Package auf Simplifier enthielt unerwünschte Text-Dateien (FSH-Quelldateien, Markdown, etc.)

**Behebung**:

* **Versionskonsistenz**: CapabilityStatement und alle SearchParameters verwenden jetzt das zentrale `Version`-Ruleset
* **CapabilityStatement**: Hardcodierte Version `2026.0.0-alpha` durch `* insert Version` ersetzt
* **SearchParameters**: `* insert Version` zu allen 6 aktiven SearchParameter-Instanzen hinzugefügt
* **SupportProfile URLs**: Alle kanonischen URLs im CapabilityStatement auf `|2026.0.4` aktualisiert

**Technische Details**:

* Lokaler Package-Build enthält ausschließlich JSON-Ressourcen (korrekt)
* Simplifier-Pipeline muss korrekten Bake-Workflow verwenden

-------

#### Version 2026.0.3

##### Maintenance Release

**Dependency Updates**

* **kerndatensatz.biobank**: Updated to `2026.0.x` (flexible versioning)

**Aktuelle Abhängigkeiten**

| | |
| :--- | :--- |
| `hl7.fhir.uv.genomics-reporting` | 3.0.x |
| `de.medizininformatikinitiative.kerndatensatz.meta` | 2026.0.x |
| `de.medizininformatikinitiative.kerndatensatz.base` | 2026.0.x |
| `de.medizininformatikinitiative.kerndatensatz.biobank` | 2026.0.x |
| `de.basisprofil.r4` | 1.5.x |
| `hl7.terminology.r4` | 6.1.x |

**Package Build**

* **ImplementationGuide-Filterung**: package.bake.yaml verbessert, um ImplementationGuide-Ressourcen aus dem FHIR-Package auszuschließen

-------

#### Version 2026.0.2

##### Hotfix: Package-Build-Fehler

**Technische Korrektur**

* **Package Build**: v2026.0.1 wurde mit fehlerhaftem Package-Build publiziert 
* Problem: Package enthielt gesamtes Repository (377 Dateien, 2.1 MB) statt nur FHIR-Ressourcen
* Ursache: Verwendung von `npm pack` anstatt `fhir bake` für Package-Erstellung
* Auswirkung: SUSHI konnte keine Ressourcen aus dem Package laden (0 resources statt 36)
* Behebung: Korrekter Build-Prozess mit `fhir bake package.bake.yaml`
* Ergebnis: Package nun korrekt strukturiert (140 Dateien, 381 KB)
 
* **Dokumentation**: build-package.md aktualisiert mit korrektem `fhir bake` Workflow 
* Explizite Verifikationsschritte für Package-Struktur
* Warnungen vor falschen Build-Methoden
 

**Hinweis**: v2026.0.1 bleibt auf Simplifier verfügbar, sollte aber nicht verwendet werden. Alle abhängigen Module sollten auf v2026.0.2 aktualisieren.

-------

#### Version 2026.0.1

##### BREAKING: Hotfix Familienanamnese Canonical URL

**Breaking Change Fix**

* **Familienanamnese Profile**: Canonical URL wiederhergestellt zur ursprünglichen Version: 
* Canonical URL: `https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/familienanamnese`
* Die URL wurde in v2026.0.0 versehentlich geändert, was ein breaking change war
* Wiederherstellung der ursprünglichen URL zur Gewährleistung der Rückwärtskompatibilität
* Betroffene abhängige Module: Seltene Erkrankungen (SE)
* Commit: 065fabf
 

**Hinweis**: Die URL `familienanamnese` entspricht zwar nicht formal den aktuellen Namenskonventionen (erwartbar wäre `mii-pr-molgen-familienanamnese`), wird aber beibehalten um breaking changes zu vermeiden.

-------

#### Version 2026.0.0

##### Änderungen nach Ballotierung

###### Vervollständigung und Korrektur der Beispiele

###### Datumsstempel für Observations (HDB-762, HDB-763)

* `effective[x]` und `issued` MS zu allen Observation-Profilen hinzugefügt

###### ServiceRequest.requester (HDB-768)

*  

| | | |
| :--- | :--- | :--- |
| Referenztypen eingeschränkt auf: Practitioner | PractitionerRole | Organization |

 

###### Terminologie-Dokumentation (HDB-749)

Konsolidierung von 18 Terminologie-Seiten in 4 übersichtliche Seiten, organisiert nach Herkunft:

* **MII-ValueSets**: Unsere 4 eigenen ValueSets (Familiäre Linie, Family Member SNOMED, Verwandtschaftsgrad, Verwandtschaftsverhältnis)
* **ClinicalGenomics**: Alle Clinical Genomics STU3 ValueSets + CodeSystems
* **Terminologien**: Externe Standards (LOINC, SNOMED CT, HGNC, HGVS, etc.) mit Lizenzinformationen
* **Index**: Übersicht mit Entscheidungskriterien zur ValueSet-Auswahl

Entfernte Einzelseiten: ClinVar-Evidence-Level, Condition-Inheritance-Pattern, DNAChangeType, Evidence-Level-Examples, Functional-Effect, HGNC, HGVS, HighLowcodes, MolecularConsequence, PharmGKB-Evidence-Level, TBD-Codes, Variant-Confidence-Status, VariantInheritance

###### BREAKING: URL-Namensraum-Migration

* `example.org` URLs durch MII FHIR Namensraum ersetzt (`https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/`)

###### Molekularer Biomarker Profil

* **Neues Profil**: `MII_PR_MolGen_MolekularerBiomarker` als gemeinsames Elternprofil für: 
* Mikrosatelliteninstabilität (erbt jetzt von MolekularerBiomarker)
* Mutationslast (erbt jetzt von MolekularerBiomarker)
 
* Basiert auf Clinical Genomics STU3 MolecularBiomarker-Profil

###### Deutsche Übersetzungen (de-DE)

* **Must Support Elemente**: Alle MS-Elemente in allen Profilen mit deutschen Übersetzungen versehen

###### Konfiguration

* `language: de` in sushi-config.yaml hinzugefügt (Issue #34)

###### CI/CD Verbesserungen

* **Automatische Releases**: GitHub Actions erstellt automatisch Draft-Releases beim Tag-Push
* **Zulip-Benachrichtigung**: Automatische Benachrichtigung im MII-Kerndatensatz Stream bei Release-Veröffentlichung
* **FHIR Package Caching**: Beschleunigte CI-Pipeline durch Caching von FHIR-Paketen

###### Familienanamnese Terminology-Bindings

* Relationship-Bindings aufgeweicht: `required` → `extensible` für SNOMED CT und v3-RoleCode
* Ermöglicht Verwendung im Seltene Erkrankungen (SE) Modul mit spezifischen Verwandtschaftsverhältnissen

###### Terminologie-Server Anforderungen

Das folgende CodeSystem muss auf dem Terminologie-Server importiert werden:

* **URL:** `http://terminology.hl7.org/CodeSystem/variant-confidence-status-cs`
* **Quelle:** https://hl7.org/fhir/uv/genomics-reporting/STU3/CodeSystem-variant-confidence-status-cs.json
* **Hinweis:** Kanonische URL hat sich von STU2 (`http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/variant-confidence-status-cs`) zu STU3 geändert

##### Strukturänderungen der Implementation Guide Navigation

###### IG-Struktur Version 2025.x (Flache Struktur)

```
MII IG Modul Molekulargenetischer Befundbericht/
├── IG MII KDS Modul Molekulargenetischer Befundbericht
├── Beschreibung Modul Molekulargenetischer Befundbericht
├── Anwendungsfälle Informationsmodell
├── Beschreibung von Szenarien für die Anwendung der Module
├── Datensätze inkl. Beschreibungen
├── Kontext im Gesamtprojekt Bezüge zu anderen Modulen
├── Technische Implementierung/
│   ├── Technische Implementierung (leer)
│   ├── FHIR Profile
│   ├── Anforderung-ServiceRequest
│   ├── Befundbericht-DiagnosticReport
│   ├── DiagnostischeImplikation-Observation
│   ├── TherapeutischeImplikation-Observation
│   ├── Variante-Observation
│   ├── ErgebnisZusammenfassung-Observation
│   ├── UntersuchteRegion-Observation
│   ├── Mikrosatelliteninstabilität-Observation
│   ├── Mutationslast-Observation
│   ├── Familienanamnese---FamilyMemberHistory
│   ├── Empfohlene Folgemaßnahme-Task
│   ├── Medikationsempfehlung-Task
│   ├── Polygener-Risiko-Score---RiskAssessment
│   ├── Genotyp---Observation
│   ├── Haplotype-Observation
│   ├── Sequence-Phase-Relationship---Observation
│   ├── CapabilityStatement
│   ├── Terminologien
│   ├── CodeSystems
│   ├── ValueSets
│   └── [Weitere einzelne Terminologie-Seiten]
├── UML
└── Referenzen

```

###### IG-Struktur Version 2026.x (Hierarchische Themengruppierung)

```
MII IG Modul Molekulargenetischer Befundbericht/
├── Hauptseite
├── Beschreibung Modul Molekulargenetischer Befundbericht
├── Anwendungsfälle / Informationsmodell/
│   ├── Index
│   ├── Basis des Informationsmodells  
│   ├── Profile-Relationships
│   └── Szenarien
├── Kontext im Gesamtprojekt Bezug zu anderen Modulen
├── Technische Implementierung/
│   ├── Index
│   ├── Workflow/
│   │   ├── Index
│   │   ├── Befundbericht-DiagnosticReport
│   │   ├── Anforderung-ServiceRequest
│   ├── Genetische Befunde/
│   │   ├── Index
│   │   ├── Variante-Observation
│   │   ├── Genotyp-Observation
│   │   ├── Haplotyp-Observation
│   │   └── Sequence-Phase-Relationship-Observation
│   ├── Genetische Implikationen/
│   │   ├── Index
│   │   ├── Molekulare Konsequenz-Observation 🆕
│   │   ├── Diagnostische Implikation-Observation
│   │   └── Therapeutische Implikation-Observation
│   ├── Molekulare Biomarker/
│   │   ├── Index
│   │   ├── Mikrosatelliteninstabilität-Observation
│   │   ├── Mutationslast-Observation
│   │   └── Polygener Risiko Score-Observation
│   ├── Therapieempfehlungen/
│   │   ├── Index
│   │   ├── EmpfohleneFolgemassnahme-Task
│   │   └── Medikationsempfehlung-Task
│   ├── Methodik/
│   │   ├── Index
│   │   ├── GenomicStudy-Procedure 🆕
│   │   └── GenomicStudyAnalysis-Procedure 🆕
│   ├── Familienanamnese/
│   │   ├── Index
│   │   ├── Familienanamnese---FamilyMemberHistory
│   │   └── Familienanamnese-Extensions 🆕
│   ├── CapabilityStatement
│   └── Terminologie/
│       ├── Index
│       ├── CodeSystems
│       └── ValueSets
│   
│   
├── Referenzen
├── Release Notes
└── Kommentierung v2026 🆕

```

###### Entfernte/Ersetzte Seiten

* ❌ ErgebnisZusammenfassung-Observation → in DiagnosticReport.conclusion
* ❌ UntersuchteRegion-Observation → GenomicStudy/GenomicStudyAnalysis

###### Neue Seiten

* 🆕 Molekulare Konsequenz (aus DiagnostischeImplikation ausgelagert)
* 🆕 GenomicStudy/GenomicStudyAnalysis (STU3)
* 🆕 Index-Seiten für jede Kategorie
* 🆕 Szenarien (konkrete Anwendungsbeispiele)
* 🆕 Kommentierung v2026

##### Technische Änderungen

###### Migration zu Clinical Genomics STU3

* Dependency auf den Clinical Genomics Reporting von STU2 auf STU3 
* Neues MolecularBiomarker-Profil
* Neues Molekulare-Konsequenz-Profil (downstream-Beschreibung von genetischen Änderungen)
* DiagnosticImplication 
* Schärfung der Profilierung mit Fokus auf Erkrankungsrisiko, Auslagerung der reinen Beschreibung der Änderung ins Molekulare-Konsequenz-Profil
* `extension[genomic-artifact]` durch `extension[workflow-relatedArtifact]` ersetzt
* component[functional-effect] in MolecularConsequence übertragen
 
* Ergebnis-Zusammenfassung 
* Löschen des Profils (Grund: Redundanzen, Ergebnis kann über GenomicReport.conclusion/conclusionCode abgebildet werden)
 
* Mikrosatelliteninstabilität 
* erbt jetzt vom STU3 Molecular Biomarker Profile
* `component[conclusion-string]` entfällt
 
* Molekulargenetischer Befundbericht erbt jetzt von genomic-report und nicht mehr genomics-report 
* wegfallen des [overall]-Slices
* Zusammenlegen der extensions für [genomics-artifact] und [genomics-file] in [workflow-relatedArtifact]
* extension[genomics-risk-assessment] ist jetzt extension[genomic-risk-assessment]
* extension[region-studied] entfällt; Metadaten über die Untersuchte Region werden jetzt über GenomicStudy/GenomicStudyAnalysis abgebildet
 
* Mutationslast 
* erbt jetzt vom neuen Molekularer Biomarker Modul
* damit entfällt `component[conclusion-string]`
 
* Therapeutische Implikation 
* `component[prognosis]` fällt **ersatzlos** weg. Geprüft gegen alle STU3-Profile: weder `therapeutic-implication` noch `diagnostic-implication`, `molecular-consequence` oder das gemeinsame Elternprofil `implication` führen einen Prognose-Slice. Wer den Wert bisher gesetzt hat, findet in STU3 keinen Platz dafür.
* `component[predicted-therapeutic-implication]` zu `component[therapeutic-implication]` geändert
 
* Untersuchte Region 
* Profil fällt weg, Information über Lokalisation und Geräte wird stattdessen über GenomicStudy/GenomicStudyAnalysis kodiert
 
* Variante 
* component[coding-hgvs] umbenannt in component[representative-coding-hgvs]
* component[transcript-ref-seq] umbenannt in component[representative-transcript-ref-seq]
* component[protein-hgvs] umbenannt in component[representative-protein-hgvs]
* component[amino-acid-change-type] gelöscht
* component[molecular-consequence] aus Variante gelöst und in MolecularConsequence überführt
 
* Beispiele entsprechend angepasst (alte Beispiele für Diagnostische Implikation entsprechen eher neuem Profil für Molekulare Konsequenz)
* Neue Ordnerstruktur im GitHub-Repo
 
* Logical Model (LogicalModel.fsh) 
* Elementnamen bereinigt: Bindestriche entfernt und durch CamelCase ersetzt (z.B. Krankengeschichte-Familie → KrankengeschichteFamilie)
* Sonderzeichen entfernt: Mikrosatelliteninstabilität → Mikrosatelliteninstabilitaet
* FHIR-Mappings entsprechend aktualisiert für Konsistenz
* Alle Elementnamen folgen jetzt FHIR-Namenskonventionen (nur alphanumerische Zeichen)
 
* Profil-Korrektur (Anforderung.fsh) 
* Typo korrigiert: "gentischer" → "genetischer" in Profile ID und InstanceOf Referenzen
* Korrekte Canonical URL: mii-pr-molgen-anforderung-genetischer-test
 
* Familienanamnese (FamilyMemberHistory.fsh) 
* Terminology-Bindings an Diagnose-Modul 2025.0.1 angeglichen
* ValueSet-Migration für ICD-10-GM, Alpha-ID, SNOMED CT und Orphanet Codings: 
* `reasonCode.coding[icd10-gm]`: `http://fhir.de/ValueSet/bfarm/icd-10-gm` → `https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/ValueSet/mii-vs-diagnose-icd10gm`
* `reasonCode.coding[alpha-id]`: `http://fhir.de/ValueSet/bfarm/alpha-id` → `https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/ValueSet/mii-vs-diagnose-alphaid`
* `reasonCode.coding[sct]`: bereits `https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/ValueSet/diagnoses-sct`
* `reasonCode.coding[orphanet]`: Neues Binding zu `https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/ValueSet/mii-vs-diagnose-orphanet`
* Gleiche Änderungen für `condition.code.coding` Slices
 
* Relationship-Bindings aufgeweicht: `required` → `extensible` für SNOMED CT und v3-RoleCode 
* Erlaubt Flexibilität bei ungewöhnlichen Verwandtschaftsverhältnissen
 
 

-------

#### Version 2025.0.0

* Package-ID aktualisiert
* Abhängigkeiten harmonisiert

