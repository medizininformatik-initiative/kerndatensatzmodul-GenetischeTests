# Coverage Plot - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2026.0.4

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Coverage Plot**

## Beispiel Media: Coverage Plot

-------

**German**

-------

**status**: Completed

**type**: Image

**subject**: [Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Krankenaktennummer (use: usual, ))](Patient-mii-exa-molgen-patient.md)

**created**: 2024-01-20 10:00:00+0100

### Contents

| | | | |
| :--- | :--- | :--- | :--- |
| - | **ContentType** | **Url** | **Title** |
| * | image/png | [https://www.medizininformatik-initiative.de/fhir/plots/coverage_wes_2024001.png](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2026.0.0&canonical=https://www.medizininformatik-initiative.de/fhir/plots/coverage_wes_2024001.png) | Exome Coverage Distribution Plot |



## Resource Content

```json
{
  "resourceType" : "Media",
  "id" : "mii-exa-molgen-media-coverage-plot",
  "status" : "completed",
  "type" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/media-type",
      "code" : "image",
      "display" : "Image"
    }]
  },
  "subject" : {
    "reference" : "Patient/mii-exa-molgen-patient"
  },
  "createdDateTime" : "2024-01-20T10:00:00+01:00",
  "content" : {
    "contentType" : "image/png",
    "url" : "https://www.medizininformatik-initiative.de/fhir/plots/coverage_wes_2024001.png",
    "title" : "Exome Coverage Distribution Plot"
  }
}

```
