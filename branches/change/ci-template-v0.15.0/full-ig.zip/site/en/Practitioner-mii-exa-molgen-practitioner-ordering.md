# Ordering Practitioner - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ordering Practitioner**

## Example Practitioner: Ordering Practitioner

-------

**English**

-------

Klaus Müller (https://www.medizininformatik-initiative.de/fhir/sid/practitioner-ids#54321)

-------



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "mii-exa-molgen-practitioner-ordering",
  "identifier" : [{
    "system" : "https://www.medizininformatik-initiative.de/fhir/sid/practitioner-ids",
    "value" : "54321"
  }],
  "name" : [{
    "family" : "Müller",
    "given" : ["Klaus"],
    "prefix" : ["Dr."]
  }]
}

```
