# mii-exa-molgen-phenotypic-feature-1 - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-molgen-phenotypic-feature-1**

## Example Observation: mii-exa-molgen-phenotypic-feature-1

-------

**English**

-------

**status**: Final

**category**: Exam

**code**: Long eyelashes

**subject**: [Melanie Marie Müller (official) Female, DoB: 2021-09-19 ( Medical record number: 146314909 (use: usual))](Patient-mii-exa-molgen-patient-2.md)

**effective**: 2022-03-13 09:30:00+0100

**performer**: [Dr. Linda Rubens(official)](Practitioner-mii-exa-molgen-practitioner-physician.md)

**value**: Present



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "mii-exa-molgen-phenotypic-feature-1",
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "exam"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://human-phenotype-ontology.org",
      "code" : "HP:0000527",
      "display" : "Long eyelashes"
    }]
  },
  "subject" : {
    "reference" : "Patient/mii-exa-molgen-patient-2"
  },
  "effectiveDateTime" : "2022-03-13T09:30:00+01:00",
  "performer" : [{
    "reference" : "Practitioner/mii-exa-molgen-practitioner-physician"
  }],
  "valueCodeableConcept" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "LA9633-4",
      "display" : "Present"
    }]
  }
}

```
