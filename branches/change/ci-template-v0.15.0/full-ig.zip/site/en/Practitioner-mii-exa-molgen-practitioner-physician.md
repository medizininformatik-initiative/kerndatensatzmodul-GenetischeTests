# mii-exa-molgen-practitioner-physician - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-molgen-practitioner-physician**

## Example Practitioner: mii-exa-molgen-practitioner-physician

-------

**English**

-------

Dr. Linda Rubens(official)

-------

| | |
| :--- | :--- |
| Active: | true |



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "mii-exa-molgen-practitioner-physician",
  "active" : true,
  "name" : [{
    "use" : "official",
    "text" : "Dr. Linda Rubens",
    "family" : "Rubens",
    "given" : ["Linda"],
    "prefix" : ["Dr."]
  }]
}

```
