# mii-exa-befund-bundle-1-braf - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2027.0.0-ballot.rc1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **mii-exa-befund-bundle-1-braf**

## Beispiel Bundle: mii-exa-befund-bundle-1-braf



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-befund-bundle-1-braf",
  "type" : "transaction",
  "timestamp" : "2022-07-14T12:11:00+01:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-befundbericht-1",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "mii-exa-molgen-befundbericht-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/molekulargenetischer-befundbericht|2027.0.0-ballot.rc1",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-report|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"DiagnosticReport_mii-exa-molgen-befundbericht-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport mii-exa-molgen-befundbericht-1</b></p><a name=\"mii-exa-molgen-befundbericht-1\"> </a><a name=\"hcmii-exa-molgen-befundbericht-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-molekulargenetischer-befundbericht.html\">MII PR MolGen Molekulargenetischer Befundbericht</a> version: 2027.0.0-ballot.rc1, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-genomic-report.html\">Genomic Report</a> version: 3.0.0</p></div><h2><span title=\"Codes:{http://loinc.org 51969-4}\">Genetic analysis report</span> (<span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span>) </h2><table class=\"grid\"><tr><td>Subject</td><td>Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</td></tr><tr><td>Performer</td><td> <a href=\"Practitioner-mii-exa-molgen-practitioner-lab.html\">Practitioner Dr. Daniel Schmidt(official)</a></td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>Relevant Time</b></td></tr><tr><td><a href=\"Observation-mii-exa-molgen-diagnostische-implikation-1.html\"><span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs diagnostic-implication}\">Diagnostic Implication</span></a></td><td/><td>Final</td><td>2022-04-07</td></tr><tr><td><a href=\"Observation-mii-exa-molgen-therapeutische-implikation-1.html\"><span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs therapeutic-implication}\">Therapeutic Implication</span></a></td><td/><td>Final</td><td>2022-04-07</td></tr><tr><td><a href=\"Observation-mii-exa-molgen-variante-1.html\"><span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></a></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td><td>Final</td><td>2022-04-07</td></tr><tr><td><a href=\"Observation-mii-exa-molgen-genotyp-1.html\"><span title=\"Codes:{http://loinc.org 84413-4}\">Genotype display name</span></a></td><td><span title=\"Codes:\">BRAF rs113488022 T&gt;A</span></td><td>Final</td><td>2022-04-07</td></tr><tr><td><a href=\"Observation-mii-exa-molgen-mutationslast-1.html\"><span title=\"Codes:{http://loinc.org 94076-7}\">Mutations/Megabase [# Ratio] in Tumor</span></a></td><td>12 Mutations/Megabase<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1/1000000{Base} = '1/1000000{Base}')</span></td><td>Final</td><td/></tr><tr><td><a href=\"Observation-mii-exa-molgen-mikrosatelliteninstabilitaet-1.html\"><span title=\"Codes:{http://loinc.org 81695-9}\">Microsatellite instability [Interpretation] in Cancer specimen Qualitative</span></a></td><td><span title=\"Codes:{http://loinc.org LA14122-8}\">Stable</span></td><td>Final</td><td/></tr></table><p>BRAF p.V600E Mutation liegt vor. Bitte Therapieoption mit einem BRAF-Inhibitor prüfen.</p></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-reference",
        "valueReference" : {
          "reference" : "Procedure/mii-exa-molgen-genomic-study-1"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/recommended-action",
        "valueReference" : {
          "reference" : "Task/mii-exa-molgen-medikationsempfehlung-1"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/recommended-action",
        "valueReference" : {
          "reference" : "Task/mii-exa-molgen-folgemassnahme-1"
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/workflow-supportingInfo",
        "valueReference" : {
          "reference" : "FamilyMemberHistory/mii-exa-molgen-family-member-history-1"
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-molgen-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE",
          "display" : "Genetics"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "51969-4",
          "display" : "Genetic analysis report"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "performer" : [{
        "reference" : "Practitioner/mii-exa-molgen-practitioner-lab"
      }],
      "specimen" : [{
        "reference" : "Specimen/mii-exa-molgen-specimen-1"
      }],
      "result" : [{
        "reference" : "Observation/mii-exa-molgen-diagnostische-implikation-1"
      },
      {
        "reference" : "Observation/mii-exa-molgen-therapeutische-implikation-1"
      },
      {
        "reference" : "Observation/mii-exa-molgen-variante-1"
      },
      {
        "reference" : "Observation/mii-exa-molgen-genotyp-1"
      },
      {
        "reference" : "Observation/mii-exa-molgen-mutationslast-1"
      },
      {
        "reference" : "Observation/mii-exa-molgen-mikrosatelliteninstabilitaet-1"
      }],
      "conclusion" : "BRAF p.V600E Mutation liegt vor. Bitte Therapieoption mit einem BRAF-Inhibitor prüfen."
    },
    "request" : {
      "method" : "PUT",
      "url" : "DiagnosticReport/mii-exa-molgen-befundbericht-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-medikationsempfehlung-1",
    "resource" : {
      "resourceType" : "Task",
      "id" : "mii-exa-molgen-medikationsempfehlung-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/medikationsempfehlung|2027.0.0-ballot.rc1",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/medication-recommendation|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Task_mii-exa-molgen-medikationsempfehlung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Task mii-exa-molgen-medikationsempfehlung-1</b></p><a name=\"mii-exa-molgen-medikationsempfehlung-1\"> </a><a name=\"hcmii-exa-molgen-medikationsempfehlung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-medikationsempfehlung.html\">MII PR MolGen Medikationsempfehlung</a> version: 2027.0.0-ballot.rc1, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-medication-recommendation.html\">Medication Recommendation</a> version: 3.0.0</p></div><p><b>basedOn</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-meta/servicerequest/example\">servicerequest/example</a></p><p><b>status</b>: Requested</p><p><b>intent</b>: proposal</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org LA26421-0}\">Alternative Medikation in Erwägung ziehen</span></p><p><b>for</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>reasonReference</b>: <a href=\"Observation-mii-exa-molgen-therapeutische-implikation-1.html\">Observation Therapeutic Implication</a></p></div></div>"
      },
      "basedOn" : [{
        "reference" : "servicerequest/example"
      }],
      "status" : "requested",
      "intent" : "proposal",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26421-0",
          "display" : "Consider alternative medication"
        }],
        "text" : "Alternative Medikation in Erwägung ziehen"
      },
      "for" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "reasonReference" : {
        "reference" : "Observation/mii-exa-molgen-therapeutische-implikation-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Task/mii-exa-molgen-medikationsempfehlung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/example-mii-molgen-folgemassnahme-1",
    "resource" : {
      "resourceType" : "Task",
      "id" : "mii-exa-molgen-folgemassnahme-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/empfohlene-folgemassnahme|2027.0.0-ballot.rc1",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/followup-recommendation|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Task_mii-exa-molgen-folgemassnahme-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Task mii-exa-molgen-folgemassnahme-1</b></p><a name=\"mii-exa-molgen-folgemassnahme-1\"> </a><a name=\"hcmii-exa-molgen-folgemassnahme-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-empfohlene-folgemassnahme.html\">MII PR MolGen Empfohlene Folgemaßnahme</a> version: 2027.0.0-ballot.rc1, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-followup-recommendation.html\">Followup Recommendation</a> version: 3.0.0</p></div><p><b>basedOn</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-meta/servicerequest/example\">servicerequest/example</a></p><p><b>status</b>: Requested</p><p><b>intent</b>: proposal</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org LA14020-4}\">Genetic counseling recommended</span></p><p><b>description</b>: Genetische Beratung empfohlen mit Dr. Rosalind Franklin</p><p><b>for</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>reasonReference</b>: <a href=\"Observation-mii-exa-molgen-therapeutische-implikation-1.html\">Observation Therapeutic Implication</a></p></div></div>"
      },
      "basedOn" : [{
        "reference" : "servicerequest/example"
      }],
      "status" : "requested",
      "intent" : "proposal",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA14020-4",
          "display" : "Genetic counseling recommended"
        }]
      },
      "description" : "Genetische Beratung empfohlen mit Dr. Rosalind Franklin",
      "for" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "reasonReference" : {
        "reference" : "Observation/mii-exa-molgen-therapeutische-implikation-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Task/mii-exa-molgen-folgemassnahme-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-family-member-history-1",
    "resource" : {
      "resourceType" : "FamilyMemberHistory",
      "id" : "mii-exa-molgen-family-member-history-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/familienanamnese|2027.0.0-ballot.rc1"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"FamilyMemberHistory_mii-exa-molgen-family-member-history-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: FamilyMemberHistory mii-exa-molgen-family-member-history-1</b></p><a name=\"mii-exa-molgen-family-member-history-1\"> </a><a name=\"hcmii-exa-molgen-family-member-history-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-molgen-familienanamnese.html\">MII PR MolGen Familienanamnese</a> version: 2027.0.0-ballot.rc1</p></div><p><b>status</b>: Completed</p><p><b>patient</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>date</b>: 2022-04-07</p><p><b>relationship</b>: <span title=\"Codes:{http://snomed.info/sct 72705000}, {http://terminology.hl7.org/CodeSystem/v3-RoleCode MTH}\">Mother (person)</span></p><p><b>sex</b>: <span title=\"Codes:{http://hl7.org/fhir/administrative-gender female}, {http://snomed.info/sct 248152002}\">Female (finding)</span></p><p><b>deceased</b>: true</p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 447886005}\">Adenocarcinoma of anorectum (disorder)</span></p><h3>Conditions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>ContributedToDeath</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 830150003}\">Malignant melanoma with B-Raf proto-oncogene, serine/threonine kinase V600E mutation (disorder)</span></td><td>true</td></tr></table></div></div>"
      },
      "status" : "completed",
      "patient" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "date" : "2022-04-07",
      "relationship" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "72705000",
          "display" : "Mother (person)"
        },
        {
          "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
          "code" : "MTH",
          "display" : "mother"
        }]
      },
      "sex" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/administrative-gender",
          "code" : "female"
        },
        {
          "system" : "http://snomed.info/sct",
          "code" : "248152002",
          "display" : "Female (finding)"
        }]
      },
      "deceasedBoolean" : true,
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "447886005",
          "display" : "Adenocarcinoma of anorectum (disorder)"
        }]
      }],
      "condition" : [{
        "code" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "830150003",
            "display" : "Malignant melanoma with B-Raf proto-oncogene, serine/threonine kinase V600E mutation (disorder)"
          }]
        },
        "contributedToDeath" : true
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "FamilyMemberHistory/mii-exa-molgen-family-member-history-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-anforderung-1",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-molgen-anforderung-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/anforderung-genetischer-test|2027.0.0-ballot.rc1"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"ServiceRequest_mii-exa-molgen-anforderung-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-molgen-anforderung-1</b></p><a name=\"mii-exa-molgen-anforderung-1\"> </a><a name=\"hcmii-exa-molgen-anforderung-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-molgen-anforderung-genetischer-test.html\">MII PR MolGen Anforderung genetischer Test</a> version: 2027.0.0-ballot.rc1</p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>category</b>: <span title=\"Codes:{http://snomed.info/sct 108252007}\">Laboratory procedure (procedure)</span></p><p><b>code</b>: <span title=\"Codes:{http://snomed.info/sct 405825005}, {http://loinc.org 53844-7}, {http://www.genenames.org/geneId HGNC:1097}\">BRAF: Exon 15 (Codon 600)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>authoredOn</b>: 2022-04-07</p><p><b>requester</b>: <a href=\"Practitioner-mii-exa-molgen-practitioner-physician.html\">Practitioner Dr. Linda Rubens(official)</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 447886005}\">Adenocarcinoma of anorectum (disorder)</span></p><p><b>supportingInfo</b>: <a href=\"FamilyMemberHistory-mii-exa-molgen-family-member-history-1.html\">FamilyMemberHistory: status = completed; date = 2022-04-07; relationship = Mother (person); sex = Female (finding); deceased[x] = true; reasonCode = Adenocarcinoma of anorectum (disorder)</a></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-molgen-specimen-1.html\">Specimen: identifier = https://biobank.uk-musterstadt.de/fhir/sid/proben#5432; status = available; type = Tissue specimen from colon (specimen)</a></p></div></div>"
      },
      "status" : "active",
      "intent" : "order",
      "category" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "108252007",
          "display" : "Laboratory procedure (procedure)"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "405825005",
          "display" : "Molecular genetic test (procedure)"
        },
        {
          "system" : "http://loinc.org",
          "code" : "53844-7",
          "display" : "BRAF gene targeted mutation analysis in Blood or Tissue by Molecular genetics method"
        },
        {
          "system" : "http://www.genenames.org/geneId",
          "code" : "HGNC:1097",
          "display" : "BRAF"
        }],
        "text" : "BRAF: Exon 15 (Codon 600)"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "authoredOn" : "2022-04-07",
      "requester" : {
        "reference" : "Practitioner/mii-exa-molgen-practitioner-physician"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "447886005",
          "display" : "Adenocarcinoma of anorectum (disorder)"
        }]
      }],
      "supportingInfo" : [{
        "reference" : "FamilyMemberHistory/mii-exa-molgen-family-member-history-1"
      }],
      "specimen" : [{
        "reference" : "Specimen/mii-exa-molgen-specimen-1"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "ServiceRequest/mii-exa-molgen-anforderung-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/example-mii-molgen-patient",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-molgen-patient",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Patient_mii-exa-molgen-patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-molgen-patient</b></p><a name=\"mii-exa-molgen-patient\"> </a><a name=\"hcmii-exa-molgen-patient\"> </a><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Known status of Patient\">Deceased:</td><td colspan=\"3\">false</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Ids (see the one above)\">Other Ids:</td><td colspan=\"3\"><ul><li>Gesetzliche Krankenversicherung/Z234567890 (use: official, )</li><li>Private Krankenversicherung/123456 (use: secondary, )</li></ul></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Alternate names (see the one above)\">Alt. Name:</td><td colspan=\"3\">Haffer (Name changed for Marriage)</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Ways to contact the Patient\">Contact Detail</td><td colspan=\"3\">Anna-Louisa-Karsch Str. 2 Berlin DE-BE 10178 DE </td></tr></table></div></div>"
      },
      "identifier" : [{
        "use" : "usual",
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR"
          }]
        },
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/patienten",
        "value" : "42285243",
        "assigner" : {
          "identifier" : {
            "system" : "https://www.medizininformatik-initiative.de/fhir/core/CodeSystem/core-location-identifier",
            "value" : "Charité"
          },
          "display" : "Charité - Universitätsmedizin Berlin"
        }
      },
      {
        "use" : "official",
        "type" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
            "code" : "GKV"
          }]
        },
        "system" : "http://fhir.de/sid/gkv/kvid-10",
        "value" : "Z234567890",
        "assigner" : {
          "identifier" : {
            "use" : "official",
            "system" : "http://fhir.de/sid/arge-ik/iknr",
            "value" : "109519005"
          }
        }
      },
      {
        "use" : "secondary",
        "type" : {
          "coding" : [{
            "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
            "code" : "PKV"
          }]
        },
        "value" : "123456",
        "assigner" : {
          "display" : "Signal Iduna"
        }
      }],
      "name" : [{
        "use" : "official",
        "family" : "Van-der-Dussen",
        "_family" : {
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-name",
            "valueString" : "Van-der-Dussen"
          }]
        },
        "given" : ["Maja", "Julia"],
        "prefix" : ["Prof. Dr. med."],
        "_prefix" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
            "valueCode" : "AC"
          }]
        }]
      },
      {
        "use" : "maiden",
        "family" : "Haffer"
      }],
      "gender" : "female",
      "birthDate" : "1968-09-19",
      "deceasedBoolean" : false,
      "address" : [{
        "type" : "both",
        "line" : ["Anna-Louisa-Karsch Str. 2"],
        "city" : "Berlin",
        "state" : "DE-BE",
        "postalCode" : "10178",
        "country" : "DE"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Patient/mii-exa-molgen-patient"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/example-mii-molgen-practitioner-lab",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-molgen-practitioner-lab",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Practitioner_mii-exa-molgen-practitioner-lab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-molgen-practitioner-lab</b></p><a name=\"mii-exa-molgen-practitioner-lab\"> </a><a name=\"hcmii-exa-molgen-practitioner-lab\"> </a><p><b>active</b>: true</p><p><b>name</b>: Dr. Daniel Schmidt(Official)</p></div></div>"
      },
      "active" : true,
      "name" : [{
        "use" : "official",
        "text" : "Dr. Daniel Schmidt",
        "family" : "Schmidt",
        "given" : ["Daniel"],
        "prefix" : ["Dr."]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Practitioner/mii-exa-molgen-practitioner-lab"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/example-mii-molgen-specimen-1",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-molgen-specimen-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/SpecimenCore"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Specimen_mii-exa-molgen-specimen-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-molgen-specimen-1</b></p><a name=\"mii-exa-molgen-specimen-1\"> </a><a name=\"hcmii-exa-molgen-specimen-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.biobank@2026.0.1&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/SpecimenCore\">MII PR Biobank Specimen Bioprobe Core</a></p></div><p><b>identifier</b>: <code>https://biobank.uk-musterstadt.de/fhir/sid/proben</code>/5432</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 128159001}\">Tissue specimen from colon (specimen)</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td><td><b>BodySite</b></td></tr><tr><td style=\"display: none\">*</td><td>2022-03-24 12:44:00+0100</td><td><span title=\"Codes:{http://snomed.info/sct 71854001}\">Colon structure (body structure)</span></td></tr></table></div></div>"
      },
      "identifier" : [{
        "system" : "https://biobank.uk-musterstadt.de/fhir/sid/proben",
        "value" : "5432"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "128159001",
          "display" : "Tissue specimen from colon (specimen)"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "collection" : {
        "collectedDateTime" : "2022-03-24T12:44:00+01:00",
        "bodySite" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "71854001",
            "display" : "Colon structure (body structure)"
          }]
        }
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Specimen/mii-exa-molgen-specimen-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-diagnostische-implikation-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-diagnostische-implikation-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/diagnostische-implikation|2027.0.0-ballot.rc1",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/diagnostic-implication|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-diagnostische-implikation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-diagnostische-implikation-1</b></p><a name=\"mii-exa-molgen-diagnostische-implikation-1\"> </a><a name=\"hcmii-exa-molgen-diagnostische-implikation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-diagnostische-implikation.html\">MII PR MolGen Diagnostische Implikation</a> version: 2027.0.0-ballot.rc1, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-diagnostic-implication.html\">Diagnostic Implication</a> version: 3.0.0</p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs diagnostic-implication}\">Diagnostic Implication</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>effective</b>: 2022-04-07</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-molgen-practitioner-lab.html\">Practitioner Dr. Daniel Schmidt(official)</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-molgen-variante-1.html\">Observation Genetic variant assessment</a></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs conclusion-string}\">Conclusion Text</span></td><td>Nachweis einer aktivierenden Mutation BRAF V600E</td></tr></table></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "diagnostic-implication",
          "display" : "Diagnostic Implication"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "effectiveDateTime" : "2022-04-07",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-molgen-practitioner-lab"
      }],
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-molgen-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "conclusion-string"
          }]
        },
        "valueString" : "Nachweis einer aktivierenden Mutation BRAF V600E"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-molgen-diagnostische-implikation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-therapeutische-implikation-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-therapeutische-implikation-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/therapeutische-implikation|2027.0.0-ballot.rc1",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/therapeutic-implication|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-therapeutische-implikation-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-therapeutische-implikation-1</b></p><a name=\"mii-exa-molgen-therapeutische-implikation-1\"> </a><a name=\"hcmii-exa-molgen-therapeutische-implikation-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-therapeutische-implikation.html\">MII PR MolGen Therapeutische Implikation</a> version: 2027.0.0-ballot.rc1, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-therapeutic-implication.html\">Therapeutic Implication</a> version: 3.0.0</p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs therapeutic-implication}\">Therapeutic Implication</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>effective</b>: 2022-04-07</p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-molgen-practitioner-lab.html\">Practitioner Dr. Daniel Schmidt(official)</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-molgen-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs conclusion-string}\">Conclusion Text</span></p><p><b>value</b>: Nachweis einer aktivierenden Mutation BRAF V600E. Triple-Therapie mit einem EGFR-Antikörper sowie einem BRAF- und einem MEK- Inhibitor prüfen.</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 51963-7}\">Medication assessed [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.whocc.no/atc L01EC}, {http://snomed.info/sct 703645005}\">BRAF Inhibitor</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 51963-7}\">Medication assessed [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.whocc.no/atc L01FE}\">EGFR (Epidermal Growth Factor Receptor) inhibitors</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 51963-7}\">Medication assessed [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.whocc.no/atc L01EE}\">Mitogen-activated protein kinase (MEK) inhibitors</span></p></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "therapeutic-implication",
          "display" : "Therapeutic Implication"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "effectiveDateTime" : "2022-04-07",
      "performer" : [{
        "reference" : "Practitioner/mii-exa-molgen-practitioner-lab"
      }],
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-molgen-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
            "code" : "conclusion-string"
          }]
        },
        "valueString" : "Nachweis einer aktivierenden Mutation BRAF V600E. Triple-Therapie mit einem EGFR-Antikörper sowie einem BRAF- und einem MEK- Inhibitor prüfen."
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "51963-7",
            "display" : "Medication assessed [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.whocc.no/atc",
            "code" : "L01EC",
            "display" : "B-Raf serine-threonine kinase (BRAF) inhibitors"
          },
          {
            "system" : "http://snomed.info/sct",
            "code" : "703645005",
            "display" : "Product containing B-Raf inhibitor (product)"
          }],
          "text" : "BRAF Inhibitor"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "51963-7",
            "display" : "Medication assessed [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.whocc.no/atc",
            "code" : "L01FE",
            "display" : "EGFR (Epidermal Growth Factor Receptor) inhibitors"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "51963-7",
            "display" : "Medication assessed [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.whocc.no/atc",
            "code" : "L01EE",
            "display" : "Mitogen-activated protein kinase (MEK) inhibitors"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-molgen-therapeutische-implikation-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-variante-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-variante-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/variante|2027.0.0-ballot.rc1",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/variant|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-variante-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-variante-1</b></p><a name=\"mii-exa-molgen-variante-1\"> </a><a name=\"hcmii-exa-molgen-variante-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-variante.html\">MII PR MolGen Variante</a> version: 2027.0.0-ballot.rc1, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-variant.html\">Variant</a> version: 3.0.0</p></div><p><b>basedOn</b>: <a href=\"ServiceRequest-mii-exa-molgen-anforderung-1.html\">ServiceRequest Molecular genetic test (procedure)</a></p><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>effective</b>: 2022-04-07</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-molgen-specimen-1.html\">Specimen: identifier = https://biobank.uk-musterstadt.de/fhir/sid/proben#5432; status = available; type = Tissue specimen from colon (specimen)</a></p><p><b>device</b>: <a href=\"Device-mii-exa-molgen-device-sequencer.html\">Device: status = active; manufacturer = Illumina</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:1097}\">BRAF</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48013-7}\">Genomic reference sequence [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.ncbi.nlm.nih.gov/refseq NM_004333.4}\">NM_004333.4</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 47999-8}\">DNA region name [Identifier]</span></p><p><b>value</b>: Exon #15</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 47999-8}\">DNA region name [Identifier]</span></p><p><b>value</b>: Codon #582 - #612</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48004-6}\">DNA change (c.HGVS)</span></p><p><b>value</b>: <span title=\"Codes:{http://varnomen.hgvs.org NM_004333.4:c.1799T&gt;A}\">NM_004333.4:c.1799T&gt;A</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48005-3}\">Amino acid change (pHGVS)</span></p><p><b>value</b>: <span title=\"Codes:{http://varnomen.hgvs.org p.(Val600Glu)}\">p.(Val600Glu)</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81258-6}\">Sample variant allelic frequency [NFr]</span></p><p><b>value</b>: 30.25 %<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code% = '%')</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48001-2}\">Cytogenetic (chromosome) location</span></p><p><b>value</b>: <span title=\"Codes:{urn:oid:2.16.840.1.113883.6.335 7q34}\">7q34</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48019-4}\">DNA change type</span></p><p><b>value</b>: <span title=\"Codes:{http://sequenceontology.org SO:1000008}\">point_mutation</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81252-9}\">Discrete genetic variant</span></p><p><b>value</b>: <span title=\"Codes:{http://www.ncbi.nlm.nih.gov/projects/SNP rs113488022}\">rs113488022</span></p></blockquote></div></div>"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-molgen-anforderung-1"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "effectiveDateTime" : "2022-04-07",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-molgen-specimen-1"
      },
      "device" : {
        "reference" : "Device/mii-exa-molgen-device-sequencer"
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:1097",
            "display" : "BRAF"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48013-7",
            "display" : "Genomic reference sequence [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.ncbi.nlm.nih.gov/refseq",
            "code" : "NM_004333.4"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "47999-8",
            "display" : "DNA region name [Identifier]"
          }]
        },
        "valueString" : "Exon #15"
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "47999-8",
            "display" : "DNA region name [Identifier]"
          }]
        },
        "valueString" : "Codon #582 - #612"
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48004-6",
            "display" : "DNA change (c.HGVS)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://varnomen.hgvs.org",
            "code" : "NM_004333.4:c.1799T>A"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48005-3",
            "display" : "Amino acid change (pHGVS)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://varnomen.hgvs.org",
            "code" : "p.(Val600Glu)"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81258-6",
            "display" : "Sample variant allelic frequency [NFr]"
          }]
        },
        "valueQuantity" : {
          "value" : 30.25,
          "system" : "http://unitsofmeasure.org",
          "code" : "%"
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48001-2",
            "display" : "Cytogenetic (chromosome) location"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "urn:oid:2.16.840.1.113883.6.335",
            "code" : "7q34"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48019-4",
            "display" : "DNA change type"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://sequenceontology.org",
            "code" : "SO:1000008",
            "display" : "point_mutation"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "81252-9",
            "display" : "Discrete genetic variant"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.ncbi.nlm.nih.gov/projects/SNP",
            "code" : "rs113488022"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-molgen-variante-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-genotyp-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-genotyp-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genotyp|2027.0.0-ballot.rc1",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genotype|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-genotyp-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-genotyp-1</b></p><a name=\"mii-exa-molgen-genotyp-1\"> </a><a name=\"hcmii-exa-molgen-genotyp-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-genotyp.html\">MII PR MolGen Genotyp</a> version: 2027.0.0-ballot.rc1, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-genotype.html\">Genotype</a> version: 3.0.0</p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 84413-4}\">Genotype display name</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>effective</b>: 2022-04-07</p><p><b>value</b>: <span title=\"Codes:\">BRAF rs113488022 T&gt;A</span></p><p><b>method</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-molgen-specimen-1.html\">Specimen: identifier = https://biobank.uk-musterstadt.de/fhir/sid/proben#5432; status = available; type = Tissue specimen from colon (specimen)</a></p><p><b>device</b>: <a href=\"Device-mii-exa-molgen-device-sequencer.html\">Device: status = active; manufacturer = Illumina</a></p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-molgen-variante-1.html\">Observation Genetic variant assessment</a></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:1097}\">BRAF</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48001-2}\">Cytogenetic (chromosome) location</span></p><p><b>value</b>: <span title=\"Codes:{urn:oid:2.16.840.1.113883.6.335 7q34}\">7q34</span></p></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "84413-4",
          "display" : "Genotype display name"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "effectiveDateTime" : "2022-04-07",
      "valueCodeableConcept" : {
        "text" : "BRAF rs113488022 T>A"
      },
      "method" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA26398-0",
          "display" : "Sequencing"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-molgen-specimen-1"
      },
      "device" : {
        "reference" : "Device/mii-exa-molgen-device-sequencer"
      },
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-molgen-variante-1"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:1097",
            "display" : "BRAF"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48001-2",
            "display" : "Cytogenetic (chromosome) location"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "urn:oid:2.16.840.1.113883.6.335",
            "code" : "7q34"
          }]
        }
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-molgen-genotyp-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-mutationslast-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-mutationslast-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/mutationslast|2027.0.0-ballot.rc1",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/tmb|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-mutationslast-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-mutationslast-1</b></p><a name=\"mii-exa-molgen-mutationslast-1\"> </a><a name=\"hcmii-exa-molgen-mutationslast-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-mutationslast.html\">MII PR MolGen Mutationslast</a> version: 2027.0.0-ballot.rc1, <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/tmb|3.0.0\">http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/tmb|3.0.0</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 94076-7}\">Mutations/Megabase [# Ratio] in Tumor</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>performer</b>: <a href=\"Practitioner-mii-exa-molgen-practitioner-lab.html\">Practitioner Dr. Daniel Schmidt(official)</a></p><p><b>value</b>: 12 Mutations/Megabase<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  code1/1000000{Base} = '1/1000000{Base}')</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-molgen-specimen-1.html\">Specimen: identifier = https://biobank.uk-musterstadt.de/fhir/sid/proben#5432; status = available; type = Tissue specimen from colon (specimen)</a></p></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category",
          "display" : "A characterization of a given biomarker observation."
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "94076-7",
          "display" : "Mutations/Megabase [# Ratio] in Tumor"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "performer" : [{
        "reference" : "Practitioner/mii-exa-molgen-practitioner-lab"
      }],
      "valueQuantity" : {
        "value" : 12,
        "unit" : "Mutations/Megabase",
        "system" : "http://unitsofmeasure.org",
        "code" : "1/1000000{Base}"
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-molgen-specimen-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-molgen-mutationslast-1"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-device-sequencer",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-molgen-device-sequencer",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Device_mii-exa-molgen-device-sequencer\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-molgen-device-sequencer</b></p><a name=\"mii-exa-molgen-device-sequencer\"> </a><a name=\"hcmii-exa-molgen-device-sequencer\"> </a><p><b>status</b>: Active</p><p><b>manufacturer</b>: Illumina</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>MiSeq</td><td>Manufacturer name</td></tr></table></div></div>"
      },
      "status" : "active",
      "manufacturer" : "Illumina",
      "deviceName" : [{
        "name" : "MiSeq",
        "type" : "manufacturer-name"
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Device/mii-exa-molgen-device-sequencer"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-practitioner-physician",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-molgen-practitioner-physician",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Practitioner_mii-exa-molgen-practitioner-physician\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-molgen-practitioner-physician</b></p><a name=\"mii-exa-molgen-practitioner-physician\"> </a><a name=\"hcmii-exa-molgen-practitioner-physician\"> </a><p><b>active</b>: true</p><p><b>name</b>: Dr. Linda Rubens(Official)</p></div></div>"
      },
      "active" : true,
      "name" : [{
        "use" : "official",
        "text" : "Dr. Linda Rubens",
        "family" : "Rubens",
        "given" : ["Linda"],
        "prefix" : ["Dr."]
      }]
    },
    "request" : {
      "method" : "PUT",
      "url" : "Practitioner/mii-exa-molgen-practitioner-physician"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/mii-exa-molgen-mikrosatelliteninstabilitaet-1",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-mikrosatelliteninstabilitaet-1",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/mikrosatelliteninstabilitaet|2027.0.0-ballot.rc1",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/msi|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-mikrosatelliteninstabilitaet-1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-mikrosatelliteninstabilitaet-1</b></p><a name=\"mii-exa-molgen-mikrosatelliteninstabilitaet-1\"> </a><a name=\"hcmii-exa-molgen-mikrosatelliteninstabilitaet-1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-mikrosatelliteninstabilitaet.html\">MII PR MolGen Mikrosatelliteninstabilität</a> version: 2027.0.0-ballot.rc1, <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/msi|3.0.0\">http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/msi|3.0.0</a></p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs biomarker-category}\">A characterization of a given biomarker observation.</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81695-9}\">Microsatellite instability [Interpretation] in Cancer specimen Qualitative</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA14122-8}\">Stable</span></p><p><b>specimen</b>: <a href=\"Specimen-mii-exa-molgen-specimen-1.html\">Specimen: identifier = https://biobank.uk-musterstadt.de/fhir/sid/proben#5432; status = available; type = Tissue specimen from colon (specimen)</a></p></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "biomarker-category",
          "display" : "A characterization of a given biomarker observation."
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "81695-9",
          "display" : "Microsatellite instability [Interpretation] in Cancer specimen Qualitative"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA14122-8",
          "display" : "Stable"
        }]
      },
      "specimen" : {
        "reference" : "Specimen/mii-exa-molgen-specimen-1"
      }
    },
    "request" : {
      "method" : "PUT",
      "url" : "Observation/mii-exa-molgen-mikrosatelliteninstabilitaet-1"
    }
  }]
}

```
