# Comprehensive WES Bundle with Full Technical Documentation - MII IG Kerndatensatz-Modul Molekulargenetischer Befundbericht v2026.0.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Comprehensive WES Bundle with Full Technical Documentation**

## Example Bundle: Comprehensive WES Bundle with Full Technical Documentation



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "mii-exa-molgen-bundle-comprehensive-wes",
  "type" : "transaction",
  "timestamp" : "2024-01-20T10:00:00+01:00",
  "entry" : [{
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Patient/mii-exa-molgen-patient-wes",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "mii-exa-molgen-patient-wes",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Patient_mii-exa-molgen-patient-wes\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient mii-exa-molgen-patient-wes</b></p><a name=\"mii-exa-molgen-patient-wes\"> </a><a name=\"hcmii-exa-molgen-patient-wes\"> </a><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</p><hr/></div></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/patient-ids",
        "value" : "WES2024001"
      }],
      "name" : [{
        "family" : "Mustermann",
        "given" : ["Max"]
      }],
      "gender" : "male",
      "birthDate" : "1970-01-01"
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Device/mii-exa-molgen-device-illumina-novaseq",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-molgen-device-illumina-novaseq",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Device_mii-exa-molgen-device-illumina-novaseq\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-molgen-device-illumina-novaseq</b></p><a name=\"mii-exa-molgen-device-illumina-novaseq\"> </a><a name=\"hcmii-exa-molgen-device-illumina-novaseq\"> </a><p><b>identifier</b>: <code>https://www.medizininformatik-initiative.de/fhir/sid/lab-devices</code>/NOVASEQ-6000-SN12345</p><p><b>status</b>: Active</p><p><b>manufacturer</b>: Illumina Inc.</p><p><b>serialNumber</b>: SN12345</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>NovaSeq 6000 Sequencing System</td><td>Model name</td></tr></table><p><b>modelNumber</b>: NovaSeq 6000</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 30234008}\">Medical laboratory analyzer</span></p></div></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/lab-devices",
        "value" : "NOVASEQ-6000-SN12345"
      }],
      "status" : "active",
      "manufacturer" : "Illumina Inc.",
      "serialNumber" : "SN12345",
      "deviceName" : [{
        "name" : "NovaSeq 6000 Sequencing System",
        "type" : "model-name"
      }],
      "modelNumber" : "NovaSeq 6000",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "30234008",
          "display" : "Medical laboratory analyzer"
        }]
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Device"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Device/mii-exa-molgen-device-thermofisher-ionchef",
    "resource" : {
      "resourceType" : "Device",
      "id" : "mii-exa-molgen-device-thermofisher-ionchef",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Device_mii-exa-molgen-device-thermofisher-ionchef\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Device mii-exa-molgen-device-thermofisher-ionchef</b></p><a name=\"mii-exa-molgen-device-thermofisher-ionchef\"> </a><a name=\"hcmii-exa-molgen-device-thermofisher-ionchef\"> </a><p><b>identifier</b>: <code>https://www.medizininformatik-initiative.de/fhir/sid/lab-devices</code>/IONCHEF-IC12345</p><p><b>status</b>: Active</p><p><b>manufacturer</b>: Thermo Fisher Scientific</p><p><b>serialNumber</b>: IC12345</p><h3>DeviceNames</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Type</b></td></tr><tr><td style=\"display: none\">*</td><td>Ion Chef System</td><td>Model name</td></tr></table><p><b>modelNumber</b>: Ion Chef</p><p><b>type</b>: <span title=\"Codes:\">Template preparation system (Ion Chef)</span></p></div></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/lab-devices",
        "value" : "IONCHEF-IC12345"
      }],
      "status" : "active",
      "manufacturer" : "Thermo Fisher Scientific",
      "serialNumber" : "IC12345",
      "deviceName" : [{
        "name" : "Ion Chef System",
        "type" : "model-name"
      }],
      "modelNumber" : "Ion Chef",
      "type" : {
        "text" : "Template preparation system (Ion Chef)"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Device"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Specimen/mii-exa-molgen-specimen-blood-edta-bundle",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-molgen-specimen-blood-edta-bundle",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Specimen_mii-exa-molgen-specimen-blood-edta-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-molgen-specimen-blood-edta-bundle</b></p><a name=\"mii-exa-molgen-specimen-blood-edta-bundle\"> </a><a name=\"hcmii-exa-molgen-specimen-blood-edta-bundle\"> </a><p><b>identifier</b>: <code>https://www.medizininformatik-initiative.de/fhir/sid/specimen-ids</code>/EDTA-2024-001</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119361006}\">Plasma specimen</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2024-01-15 09:30:00+0100</td></tr></table><h3>Containers</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Capacity</b></td><td><b>SpecimenQuantity</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://snomed.info/sct 767384004}\">Evacuated blood collection tube with clot activator</span></td><td>10 milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td><td>10 milliliter<span style=\"background: LightGoldenRodYellow\"> (Details: UCUM  codemL = 'mL')</span></td></tr></table></div></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/specimen-ids",
        "value" : "EDTA-2024-001"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119361006",
          "display" : "Plasma specimen"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      },
      "collection" : {
        "collectedDateTime" : "2024-01-15T09:30:00+01:00"
      },
      "container" : [{
        "type" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "767384004",
            "display" : "Evacuated blood collection tube with clot activator"
          }]
        },
        "capacity" : {
          "value" : 10,
          "unit" : "milliliter",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        },
        "specimenQuantity" : {
          "value" : 10,
          "unit" : "milliliter",
          "system" : "http://unitsofmeasure.org",
          "code" : "mL"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Specimen"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Specimen/mii-exa-molgen-specimen-dna-library-bundle",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "mii-exa-molgen-specimen-dna-library-bundle",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Specimen_mii-exa-molgen-specimen-dna-library-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen mii-exa-molgen-specimen-dna-library-bundle</b></p><a name=\"mii-exa-molgen-specimen-dna-library-bundle\"> </a><a name=\"hcmii-exa-molgen-specimen-dna-library-bundle\"> </a><p><b>identifier</b>: <code>https://www.medizininformatik-initiative.de/fhir/sid/specimen-ids</code>/LIB-2024-001</p><p><b>type</b>: <span title=\"Codes:{http://snomed.info/sct 119342007}\">DNA Library</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p><p><b>parent</b>: <a href=\"Specimen-mii-exa-molgen-specimen-blood-edta.html\">Specimen: identifier = https://www.medizininformatik-initiative.de/fhir/sid/specimen-ids#EDTA-2024-001; type = Plasma specimen</a></p><h3>Processings</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Description</b></td><td><b>Time[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>DNA extraction and library preparation using Agilent SureSelect</td><td>2024-01-16 14:00:00+0100</td></tr></table></div></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/specimen-ids",
        "value" : "LIB-2024-001"
      }],
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "119342007",
          "display" : "Saliva specimen"
        }],
        "text" : "DNA Library"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      },
      "parent" : [{
        "reference" : "Specimen/mii-exa-molgen-specimen-blood-edta"
      }],
      "processing" : [{
        "description" : "DNA extraction and library preparation using Agilent SureSelect",
        "timeDateTime" : "2024-01-16T14:00:00+01:00"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Specimen"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/PlanDefinition/mii-exa-molgen-protocol-agilent-sureselect",
    "resource" : {
      "resourceType" : "PlanDefinition",
      "id" : "mii-exa-molgen-protocol-agilent-sureselect",
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"PlanDefinition_mii-exa-molgen-protocol-agilent-sureselect\"> </a>\n<div>\n    <table class=\"grid dict\">\n        \n        <tr>\n            <th scope=\"row\"><b>Id: </b></th>\n            <td style=\"padding-left: 4px;\">mii-exa-molgen-protocol-agilent-sureselect</td>\n        </tr>\n        \n\n        \n\n        \n\n        \n\n        \n        <tr>\n            <th scope=\"row\"><b>Title: </b></th>\n            <td style=\"padding-left: 4px;\">Agilent SureSelect Human All Exon V7 Kit Protocol</td>\n        </tr>\n        \n\n        \n\n        \n\n        \n\n        \n        <tr>\n            <th scope=\"row\"><b>Type: </b></th>\n            <td style=\"padding-left: 4px;\">\n                \n                    \n                        \n                        <p style=\"margin-bottom: 5px;\">\n                            <b>system: </b> <span><a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-plan-definition-type.html\">http://terminology.hl7.org/CodeSystem/plan-definition-type</a></span>\n                        </p>\n                        \n                        \n                        <p style=\"margin-bottom: 5px;\">\n                            <b>code: </b> <span>protocol</span>\n                        </p>\n                        \n                        \n                        <p style=\"margin-bottom: 5px;\">\n                            <b>display: </b> <span>Protocol</span>\n                        </p>\n                        \n                    \n                \n                \n            </td>\n        </tr>\n        \n\n        \n\n        \n\n        \n\n        \n        <tr>\n            <th scope=\"row\"><b>Description: </b></th>\n            <td style=\"padding-left: 4px;\"><div><p>Target enrichment protocol for whole exome sequencing covering 35.8 Mb of the human exome</p>\n</div></td>\n        </tr>\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n\n        \n        <tr>\n            <th scope=\"row\"><b>Actions: </b></th>\n            <td style=\"padding-left: 4px;\">\n                <table class=\"grid-dict\">\n                    \n                    <tr>\n                        <td>\n                            \n                            <b> DNA Fragmentation:</b> Fragment genomic DNA to 150-200bp using Covaris\n                            \n                            <br/>\n                            \n                            \n                            \n                            \n                            \n                        </td>\n                    </tr>\n                    \n                    <tr>\n                        <td>\n                            \n                            <b> Library Preparation:</b> End repair, A-tailing, adapter ligation\n                            \n                            <br/>\n                            \n                            \n                            \n                            \n                            \n                        </td>\n                    </tr>\n                    \n                    <tr>\n                        <td>\n                            \n                            <b> Hybridization:</b> Hybridize with SureSelect baits for 24 hours at 65°C\n                            \n                            <br/>\n                            \n                            \n                            \n                            \n                            \n                        </td>\n                    </tr>\n                    \n                    <tr>\n                        <td>\n                            \n                            <b> Capture:</b> Streptavidin bead capture and washing\n                            \n                            <br/>\n                            \n                            \n                            \n                            \n                            \n                        </td>\n                    </tr>\n                    \n                    <tr>\n                        <td>\n                            \n                            <b> Amplification:</b> PCR amplification of captured library\n                            \n                            <br/>\n                            \n                            \n                            \n                            \n                            \n                        </td>\n                    </tr>\n                    \n                </table>\n            </td>\n        </tr>\n        \n    </table>\n</div>\n</div></div>"
      },
      "name" : "AgilentSureSelectV7",
      "title" : "Agilent SureSelect Human All Exon V7 Kit Protocol",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/plan-definition-type",
          "code" : "protocol",
          "display" : "Protocol"
        }]
      },
      "status" : "active",
      "description" : "Target enrichment protocol for whole exome sequencing covering 35.8 Mb of the human exome",
      "action" : [{
        "title" : "DNA Fragmentation",
        "description" : "Fragment genomic DNA to 150-200bp using Covaris"
      },
      {
        "title" : "Library Preparation",
        "description" : "End repair, A-tailing, adapter ligation"
      },
      {
        "title" : "Hybridization",
        "description" : "Hybridize with SureSelect baits for 24 hours at 65°C"
      },
      {
        "title" : "Capture",
        "description" : "Streptavidin bead capture and washing"
      },
      {
        "title" : "Amplification",
        "description" : "PCR amplification of captured library"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "PlanDefinition"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/DocumentReference/mii-exa-molgen-documentreference-bed-file-bundle",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "mii-exa-molgen-documentreference-bed-file-bundle",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"DocumentReference_mii-exa-molgen-documentreference-bed-file-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference mii-exa-molgen-documentreference-bed-file-bundle</b></p><a name=\"mii-exa-molgen-documentreference-bed-file-bundle\"> </a><a name=\"hcmii-exa-molgen-documentreference-bed-file-bundle\"> </a><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:\">BED file - Agilent SureSelect V7 target regions</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>text/plain</td><td><a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/files/agilent_v7_targets.bed\">https://www.medizininformatik-initiative.de/fhir/files/agilent_v7_targets.bed</a></td><td>Agilent SureSelect Human All Exon V7 Target Regions</td></tr></table></blockquote></div></div>"
      },
      "status" : "current",
      "type" : {
        "text" : "BED file - Agilent SureSelect V7 target regions"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      },
      "content" : [{
        "attachment" : {
          "contentType" : "text/plain",
          "url" : "https://www.medizininformatik-initiative.de/fhir/files/agilent_v7_targets.bed",
          "title" : "Agilent SureSelect Human All Exon V7 Target Regions"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "DocumentReference"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/DocumentReference/mii-exa-molgen-documentreference-fastq-bundle",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "mii-exa-molgen-documentreference-fastq-bundle",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"DocumentReference_mii-exa-molgen-documentreference-fastq-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference mii-exa-molgen-documentreference-fastq-bundle</b></p><a name=\"mii-exa-molgen-documentreference-fastq-bundle\"> </a><a name=\"hcmii-exa-molgen-documentreference-fastq-bundle\"> </a><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:\">FASTQ files - paired-end sequencing data</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>application/gzip</td><td><a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/files/sample_R1.fastq.gz\">https://www.medizininformatik-initiative.de/fhir/files/sample_R1.fastq.gz</a></td><td>Forward reads</td></tr></table></blockquote><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>application/gzip</td><td><a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/files/sample_R2.fastq.gz\">https://www.medizininformatik-initiative.de/fhir/files/sample_R2.fastq.gz</a></td><td>Reverse reads</td></tr></table></blockquote></div></div>"
      },
      "status" : "current",
      "type" : {
        "text" : "FASTQ files - paired-end sequencing data"
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      },
      "content" : [{
        "attachment" : {
          "contentType" : "application/gzip",
          "url" : "https://www.medizininformatik-initiative.de/fhir/files/sample_R1.fastq.gz",
          "title" : "Forward reads"
        }
      },
      {
        "attachment" : {
          "contentType" : "application/gzip",
          "url" : "https://www.medizininformatik-initiative.de/fhir/files/sample_R2.fastq.gz",
          "title" : "Reverse reads"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "DocumentReference"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Procedure/mii-exa-molgen-genomic-study-comprehensive-wes-bundle",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-molgen-genomic-study-comprehensive-wes-bundle",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/mii-pr-molgen-genomic-study",
        "https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study|2026.0.4"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Procedure_mii-exa-molgen-genomic-study-comprehensive-wes-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-molgen-genomic-study-comprehensive-wes-bundle</b></p><a name=\"mii-exa-molgen-genomic-study-comprehensive-wes-bundle\"> </a><a name=\"hcmii-exa-molgen-genomic-study-comprehensive-wes-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-genomic-study.html\">MII PR MolGen Genomic Study</a>, <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study|2026.0.4\">https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study|2026.0.4</a></p></div><p><b>Genomic Study Analysis Extension</b>: <a href=\"Procedure-mii-exa-molgen-genomic-study-analysis-wes-library-prep.html\">Procedure: extension = -&gt;Specimen: identifier = https://www.medizininformatik-initiative.de/fhir/sid/specimen-ids#EDTA-2024-001; type = Plasma specimen,,DNA hybridization; status = completed; category = Laboratory</a></p><p><b>Genomic Study Analysis Extension</b>: <a href=\"Procedure-mii-exa-molgen-genomic-study-analysis-wes-sequencing.html\">Procedure: extension = -&gt;Specimen: identifier = https://www.medizininformatik-initiative.de/fhir/sid/specimen-ids#LIB-2024-001; type = Saliva specimen,,Sequencing,,; status = completed; category = Laboratory</a></p><p><b>Genomic Study Analysis Extension</b>: <a href=\"Procedure-mii-exa-molgen-genomic-study-analysis-wes-bioinformatics.html\">Procedure: extension = ,Computational analysis,; status = completed; category = Laboratory</a></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-ext",
        "valueReference" : {
          "reference" : "Procedure/mii-exa-molgen-genomic-study-analysis-wes-library-prep"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-ext",
        "valueReference" : {
          "reference" : "Procedure/mii-exa-molgen-genomic-study-analysis-wes-sequencing"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-ext",
        "valueReference" : {
          "reference" : "Procedure/mii-exa-molgen-genomic-study-analysis-wes-bioinformatics"
        }
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Procedure"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Procedure/mii-exa-molgen-genomic-study-analysis-wes-library-prep-bundle",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-molgen-genomic-study-analysis-wes-library-prep-bundle",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/mii-pr-molgen-genomic-study-analysis",
        "https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study-analysis|2026.0.4"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Procedure_mii-exa-molgen-genomic-study-analysis-wes-library-prep-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-molgen-genomic-study-analysis-wes-library-prep-bundle</b></p><a name=\"mii-exa-molgen-genomic-study-analysis-wes-library-prep-bundle\"> </a><a name=\"hcmii-exa-molgen-genomic-study-analysis-wes-library-prep-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-genomic-study-analysis.html\">MII PR MolGen Genomic Study Analysis</a>, <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study-analysis|2026.0.4\">https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study-analysis|2026.0.4</a></p></div><p><b>Genomic Study Analysis Specimen</b>: <a href=\"Specimen-mii-exa-molgen-specimen-blood-edta.html\">Specimen: identifier = https://www.medizininformatik-initiative.de/fhir/sid/specimen-ids#EDTA-2024-001; type = Plasma specimen</a></p><blockquote><p><b>Genomic Study Analysis Device</b></p><ul><li>device: <a href=\"Device-mii-exa-molgen-device-thermofisher-ionchef.html\">Device: identifier = https://www.medizininformatik-initiative.de/fhir/sid/lab-devices#IONCHEF-IC12345; status = active; manufacturer = Thermo Fisher Scientific; serialNumber = IC12345; modelNumber = Ion Chef; type = </a></li></ul></blockquote><p><b>Genomic Study Analysis Method Type</b>: <span title=\"Codes:{http://loinc.org LA26810-4}\">DNA hybridization</span></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-specimen",
        "valueReference" : {
          "reference" : "Specimen/mii-exa-molgen-specimen-blood-edta"
        }
      },
      {
        "extension" : [{
          "url" : "device",
          "valueReference" : {
            "reference" : "Device/mii-exa-molgen-device-thermofisher-ionchef"
          }
        }],
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-device"
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-method-type",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26810-4",
            "display" : "DNA hybridization"
          }]
        }
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Procedure"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Procedure/mii-exa-molgen-genomic-study-analysis-wes-sequencing-bundle",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-molgen-genomic-study-analysis-wes-sequencing-bundle",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/mii-pr-molgen-genomic-study-analysis",
        "https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study-analysis|2026.0.4"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Procedure_mii-exa-molgen-genomic-study-analysis-wes-sequencing-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-molgen-genomic-study-analysis-wes-sequencing-bundle</b></p><a name=\"mii-exa-molgen-genomic-study-analysis-wes-sequencing-bundle\"> </a><a name=\"hcmii-exa-molgen-genomic-study-analysis-wes-sequencing-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-genomic-study-analysis.html\">MII PR MolGen Genomic Study Analysis</a>, <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study-analysis|2026.0.4\">https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study-analysis|2026.0.4</a></p></div><p><b>Genomic Study Analysis Specimen</b>: <a href=\"Specimen-mii-exa-molgen-specimen-dna-library.html\">Specimen: identifier = https://www.medizininformatik-initiative.de/fhir/sid/specimen-ids#LIB-2024-001; type = Saliva specimen</a></p><blockquote><p><b>Genomic Study Analysis Device</b></p><ul><li>device: <a href=\"Device-mii-exa-molgen-device-illumina-novaseq.html\">Device: identifier = https://www.medizininformatik-initiative.de/fhir/sid/lab-devices#NOVASEQ-6000-SN12345; status = active; manufacturer = Illumina Inc.; serialNumber = SN12345; modelNumber = NovaSeq 6000; type = Medical laboratory analyzer</a></li></ul></blockquote><p><b>Genomic Study Analysis Method Type</b>: <span title=\"Codes:{http://loinc.org LA26398-0}\">Sequencing</span></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-specimen",
        "valueReference" : {
          "reference" : "Specimen/mii-exa-molgen-specimen-dna-library"
        }
      },
      {
        "extension" : [{
          "url" : "device",
          "valueReference" : {
            "reference" : "Device/mii-exa-molgen-device-illumina-novaseq"
          }
        }],
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-device"
      },
      {
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-method-type",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26398-0",
            "display" : "Sequencing"
          }]
        }
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Procedure"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Procedure/mii-exa-molgen-genomic-study-analysis-wes-bioinformatics-bundle",
    "resource" : {
      "resourceType" : "Procedure",
      "id" : "mii-exa-molgen-genomic-study-analysis-wes-bioinformatics-bundle",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/mii-pr-molgen-genomic-study-analysis",
        "https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study-analysis|2026.0.4"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Procedure_mii-exa-molgen-genomic-study-analysis-wes-bioinformatics-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Procedure mii-exa-molgen-genomic-study-analysis-wes-bioinformatics-bundle</b></p><a name=\"mii-exa-molgen-genomic-study-analysis-wes-bioinformatics-bundle\"> </a><a name=\"hcmii-exa-molgen-genomic-study-analysis-wes-bioinformatics-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-genomic-study-analysis.html\">MII PR MolGen Genomic Study Analysis</a>, <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study-analysis|2026.0.4\">https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/genomic-study-analysis|2026.0.4</a></p></div><p><b>Genomic Study Analysis Method Type</b>: <span title=\"Codes:{http://loinc.org LA26811-2}\">Computational analysis</span></p><p><b>status</b>: Completed</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-analysis-method-type",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA26811-2",
            "display" : "Computational analysis"
          }]
        }
      }],
      "status" : "completed",
      "category" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Procedure"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/ServiceRequest/mii-exa-molgen-anforderung-wes-bundle",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "mii-exa-molgen-anforderung-wes-bundle",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/anforderung-genetischer-test|2026.0.4"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"ServiceRequest_mii-exa-molgen-anforderung-wes-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest mii-exa-molgen-anforderung-wes-bundle</b></p><a name=\"mii-exa-molgen-anforderung-wes-bundle\"> </a><a name=\"hcmii-exa-molgen-anforderung-wes-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-molgen-anforderung-genetischer-test.html\">MII PR MolGen Anforderung genetischer Test</a> version: 2026.0.4</p></div><p><b>status</b>: Completed</p><p><b>intent</b>: Order</p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 86205-2}\">Whole exome sequence analysis in Blood or Tissue by Molecular genetics method</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p><p><b>authoredOn</b>: 2024-01-10</p><p><b>requester</b>: <a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/modul-meta/Practitioner/mii-exa-molgen-practitioner\">Practitioner/mii-exa-molgen-practitioner</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://snomed.info/sct 110359009}\">Intellectual disability (disorder)</span></p></div></div>"
      },
      "status" : "completed",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "86205-2",
          "display" : "Whole exome sequence analysis in Blood or Tissue by Molecular genetics method"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      },
      "authoredOn" : "2024-01-10",
      "requester" : {
        "reference" : "Practitioner/mii-exa-molgen-practitioner"
      },
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "110359009",
          "display" : "Intellectual disability (disorder)"
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "ServiceRequest"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Observation/mii-exa-molgen-variante-comprehensive-pathogenic-bundle",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-variante-comprehensive-pathogenic-bundle",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/variante|2026.0.4"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-variante-comprehensive-pathogenic-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-variante-comprehensive-pathogenic-bundle</b></p><a name=\"mii-exa-molgen-variante-comprehensive-pathogenic-bundle\"> </a><a name=\"hcmii-exa-molgen-variante-comprehensive-pathogenic-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-molgen-variante.html\">MII PR MolGen Variante</a> version: 2026.0.4</p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p><p><b>effective</b>: 2024-01-10</p><p><b>value</b>: <span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48018-6}\">Gene studied [ID]</span></p><p><b>value</b>: <span title=\"Codes:{http://www.genenames.org/geneId HGNC:7132}\">KMT2A</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48004-6}\">DNA change (c.HGVS)</span></p><p><b>value</b>: <span title=\"Codes:{http://varnomen.hgvs.org NM_005933.3:c.3463C&gt;T}\">NM_005933.3:c.3463C&gt;T</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 48005-3}\">Amino acid change (pHGVS)</span></p><p><b>value</b>: <span title=\"Codes:{http://varnomen.hgvs.org p.(Arg1155Ter)}\">p.(Arg1155Ter)</span></p></blockquote></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "69548-6",
          "display" : "Genetic variant assessment"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      },
      "effectiveDateTime" : "2024-01-10",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA9633-4",
          "display" : "Present"
        }]
      },
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48018-6",
            "display" : "Gene studied [ID]"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://www.genenames.org/geneId",
            "code" : "HGNC:7132",
            "display" : "KMT2A"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48004-6",
            "display" : "DNA change (c.HGVS)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://varnomen.hgvs.org",
            "code" : "NM_005933.3:c.3463C>T",
            "display" : "NM_005933.3:c.3463C>T"
          }]
        }
      },
      {
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "48005-3",
            "display" : "Amino acid change (pHGVS)"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://varnomen.hgvs.org",
            "code" : "p.(Arg1155Ter)",
            "display" : "p.(Arg1155Ter)"
          }]
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Observation/mii-exa-molgen-diagnostische-implikation-comprehensive-bundle",
    "resource" : {
      "resourceType" : "Observation",
      "id" : "mii-exa-molgen-diagnostische-implikation-comprehensive-bundle",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/diagnostische-implikation|2026.0.4"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Observation_mii-exa-molgen-diagnostische-implikation-comprehensive-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation mii-exa-molgen-diagnostische-implikation-comprehensive-bundle</b></p><a name=\"mii-exa-molgen-diagnostische-implikation-comprehensive-bundle\"> </a><a name=\"hcmii-exa-molgen-diagnostische-implikation-comprehensive-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-mii-pr-molgen-diagnostische-implikation.html\">MII PR MolGen Diagnostische Implikation</a> version: 2026.0.4</p></div><p><b>status</b>: Final</p><p><b>category</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/observation-category laboratory}\">Laboratory</span>, <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span></p><p><b>code</b>: <span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs diagnostic-implication}\">Diagnostic Implication</span></p><p><b>subject</b>: <a href=\"Bundle-mii-exa-molgen-bundle-comprehensive-wes.html#Patient_mii-exa-molgen-patient-wes\">Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</a></p><p><b>effective</b>: 2024-01-10</p><p><b>derivedFrom</b>: <a href=\"Observation-mii-exa-molgen-variante-comprehensive-pathogenic.html\">Observation Genetic variant assessment</a></p><h3>Components</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://loinc.org 53037-8}\">Genetic variation clinical significance [Imp]</span></td><td><span title=\"Codes:{http://loinc.org LA6668-3}\">Pathogenic</span></td></tr></table></div></div>"
      },
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "laboratory",
          "display" : "Laboratory"
        }]
      },
      {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs",
          "code" : "diagnostic-implication",
          "display" : "Diagnostic Implication"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      },
      "effectiveDateTime" : "2024-01-10",
      "derivedFrom" : [{
        "reference" : "Observation/mii-exa-molgen-variante-comprehensive-pathogenic"
      }],
      "component" : [{
        "code" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "53037-8"
          }]
        },
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "LA6668-3",
            "display" : "Pathogenic"
          }]
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Observation"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Media/mii-exa-molgen-media-coverage-plot",
    "resource" : {
      "resourceType" : "Media",
      "id" : "mii-exa-molgen-media-coverage-plot",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Media_mii-exa-molgen-media-coverage-plot\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Media mii-exa-molgen-media-coverage-plot</b></p><a name=\"mii-exa-molgen-media-coverage-plot\"> </a><a name=\"hcmii-exa-molgen-media-coverage-plot\"> </a><p><b>status</b>: Completed</p><p><b>type</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/media-type image}\">Image</span></p><p><b>subject</b>: <a href=\"Patient-mii-exa-molgen-patient.html\">Maja Julia Van-der-Dussen (official) Female, DoB: 1968-09-19 ( Medical record number (use: usual, ))</a></p><p><b>created</b>: 2024-01-20 10:00:00+0100</p><h3>Contents</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td><td><b>Title</b></td></tr><tr><td style=\"display: none\">*</td><td>image/png</td><td><a href=\"https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.meta@2027.0.0-ballot.rc3&amp;canonical=https://www.medizininformatik-initiative.de/fhir/plots/coverage_wes_2024001.png\">https://www.medizininformatik-initiative.de/fhir/plots/coverage_wes_2024001.png</a></td><td>Exome Coverage Distribution Plot</td></tr></table></div></div>"
      },
      "status" : "completed",
      "type" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/media-type",
          "code" : "image",
          "display" : "Image"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient"
      },
      "createdDateTime" : "2024-01-20T10:00:00+01:00",
      "content" : {
        "contentType" : "image/png",
        "url" : "https://www.medizininformatik-initiative.de/fhir/plots/coverage_wes_2024001.png",
        "title" : "Exome Coverage Distribution Plot"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Media"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/DiagnosticReport/mii-exa-molgen-befundbericht-comprehensive-wes-bundle",
    "resource" : {
      "resourceType" : "DiagnosticReport",
      "id" : "mii-exa-molgen-befundbericht-comprehensive-wes-bundle",
      "meta" : {
        "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-molgen/StructureDefinition/molekulargenetischer-befundbericht|2026.0.4",
        "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-report|3.0.0"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"DiagnosticReport_mii-exa-molgen-befundbericht-comprehensive-wes-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DiagnosticReport mii-exa-molgen-befundbericht-comprehensive-wes-bundle</b></p><a name=\"mii-exa-molgen-befundbericht-comprehensive-wes-bundle\"> </a><a name=\"hcmii-exa-molgen-befundbericht-comprehensive-wes-bundle\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-mii-pr-molgen-molekulargenetischer-befundbericht.html\">MII PR MolGen Molekulargenetischer Befundbericht</a> version: 2026.0.4, <a href=\"http://hl7.org/fhir/uv/genomics-reporting/STU3/StructureDefinition-genomic-report.html\">Genomic Report</a> version: 3.0.0</p></div><h2><span title=\"Codes:{http://loinc.org 51969-4}\">Genetic analysis report</span> (<span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0074 GE}\">Genetics</span>) </h2><table class=\"grid\"><tr><td>Subject</td><td>Max Mustermann  Male, DoB: 1970-01-01 ( https://www.medizininformatik-initiative.de/fhir/patient-ids#WES2024001)</td></tr><tr><td>Performer</td><td> <a href=\"Practitioner-mii-exa-molgen-practitioner-lab.html\">Practitioner Dr. Daniel Schmidt(official)</a></td></tr></table><p><b>Report Details</b></p><table class=\"grid\"><tr><td><b>Code</b></td><td><b>Value</b></td><td><b>Flags</b></td><td><b>Relevant Time</b></td></tr><tr><td><a href=\"Observation-mii-exa-molgen-variante-comprehensive-pathogenic.html\"><span title=\"Codes:{http://loinc.org 69548-6}\">Genetic variant assessment</span></a></td><td><span title=\"Codes:{http://loinc.org LA9633-4}\">Present</span></td><td>Final</td><td>2024-01-10</td></tr><tr><td><a href=\"Observation-mii-exa-molgen-diagnostische-implikation-comprehensive.html\"><span title=\"Codes:{http://hl7.org/fhir/uv/genomics-reporting/CodeSystem/tbd-codes-cs diagnostic-implication}\">Diagnostic Implication</span></a></td><td/><td>Final</td><td>2024-01-10</td></tr></table><p>Whole exome sequencing identified a pathogenic de novo variant in the KMT2A gene, consistent with Wiedemann-Steiner syndrome. Technical quality metrics met all acceptance criteria.</p><p><b>Coded Conclusions:</b></p><ul><li><span title=\"Codes:{http://loinc.org LA6576-8}\">Positive</span></li></ul></div></div>"
      },
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/genomics-reporting/StructureDefinition/genomic-study-reference",
        "valueReference" : {
          "reference" : "Procedure/mii-exa-molgen-genomic-study-comprehensive-wes"
        }
      }],
      "basedOn" : [{
        "reference" : "ServiceRequest/mii-exa-molgen-anforderung-wes"
      }],
      "status" : "final",
      "category" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v2-0074",
          "code" : "GE",
          "display" : "Genetics"
        }]
      }],
      "code" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "51969-4",
          "display" : "Genetic analysis report"
        }]
      },
      "subject" : {
        "reference" : "Patient/mii-exa-molgen-patient-wes"
      },
      "performer" : [{
        "reference" : "Practitioner/mii-exa-molgen-practitioner-lab"
      }],
      "specimen" : [{
        "reference" : "Specimen/mii-exa-molgen-specimen-blood-edta"
      }],
      "result" : [{
        "reference" : "Observation/mii-exa-molgen-variante-comprehensive-pathogenic"
      },
      {
        "reference" : "Observation/mii-exa-molgen-diagnostische-implikation-comprehensive"
      }],
      "media" : [{
        "comment" : "Coverage plot showing uniform coverage across all exons",
        "link" : {
          "reference" : "Media/mii-exa-molgen-media-coverage-plot"
        }
      }],
      "conclusion" : "Whole exome sequencing identified a pathogenic de novo variant in the KMT2A gene, consistent with Wiedemann-Steiner syndrome. Technical quality metrics met all acceptance criteria.",
      "conclusionCode" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "LA6576-8",
          "display" : "Positive"
        }]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "DiagnosticReport"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Practitioner/mii-exa-molgen-practitioner-bundle",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-molgen-practitioner-bundle",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Practitioner_mii-exa-molgen-practitioner-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-molgen-practitioner-bundle</b></p><a name=\"mii-exa-molgen-practitioner-bundle\"> </a><a name=\"hcmii-exa-molgen-practitioner-bundle\"> </a><p><b>identifier</b>: <code>https://www.medizininformatik-initiative.de/fhir/sid/practitioner-ids</code>/12345</p><p><b>name</b>: Anna Schmidt </p></div></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/practitioner-ids",
        "value" : "12345"
      }],
      "name" : [{
        "family" : "Schmidt",
        "given" : ["Anna"],
        "prefix" : ["Dr."]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Practitioner"
    }
  },
  {
    "fullUrl" : "https://www.medizininformatik-initiative.de/fhir/Practitioner/mii-exa-molgen-practitioner-lab-bundle",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "mii-exa-molgen-practitioner-lab-bundle",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><div xml:lang=\"en\" lang=\"en\"><hr/><p><b>English</b></p><hr/><a name=\"Practitioner_mii-exa-molgen-practitioner-lab-bundle\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Practitioner mii-exa-molgen-practitioner-lab-bundle</b></p><a name=\"mii-exa-molgen-practitioner-lab-bundle\"> </a><a name=\"hcmii-exa-molgen-practitioner-lab-bundle\"> </a><p><b>identifier</b>: <code>https://www.medizininformatik-initiative.de/fhir/sid/practitioner-ids</code>/67890</p><p><b>name</b>: Thomas Weber </p></div></div>"
      },
      "identifier" : [{
        "system" : "https://www.medizininformatik-initiative.de/fhir/sid/practitioner-ids",
        "value" : "67890"
      }],
      "name" : [{
        "family" : "Weber",
        "given" : ["Thomas"],
        "prefix" : ["Dr."]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Practitioner"
    }
  }]
}

```
